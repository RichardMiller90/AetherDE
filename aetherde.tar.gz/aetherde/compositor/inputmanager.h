#pragma once
// compositor/inputmanager.h
// SPDX-License-Identifier: MIT

#include <QObject>
#include <QPointF>
#include <QKeyCombination>

class QWaylandSeat;
class AetherCompositor;
struct libinput;
struct libinput_event;

// ─────────────────────────────────────────────────────────────────────────────
// InputManager manages libinput events and routes them through QWaylandSeat.
//
// On FreeBSD this requires membership of the "operator" group (or root) for
// /dev/input access, or the use of libseat for unprivileged access.
// ─────────────────────────────────────────────────────────────────────────────
class InputManager : public QObject
{
    Q_OBJECT
public:
    explicit InputManager(AetherCompositor *compositor);
    ~InputManager() override;

    QWaylandSeat *seat() const { return m_seat; }

    // Called per compositor frame to drain pending libinput events
    void processEvents();

    // Pointer state
    QPointF    pointerPos()    const { return m_pointerPos; }
    Qt::MouseButtons buttons() const { return m_buttons; }

signals:
    void pointerMoved(const QPointF &pos);
    void pointerButton(Qt::MouseButton button, bool pressed, const QPointF &pos);
    void keyEvent(int key, Qt::KeyboardModifiers mods, bool pressed, const QString &text);
    void touchEvent();

private:
    void handlePointerMotion(libinput_event *ev);
    void handlePointerButton(libinput_event *ev);
    void handlePointerAxis(libinput_event *ev);
    void handleKeyboard(libinput_event *ev);
    void handleTouch(libinput_event *ev);

    AetherCompositor *m_compositor;
    QWaylandSeat     *m_seat;
    struct libinput  *m_li        = nullptr;
    QPointF           m_pointerPos{0, 0};
    Qt::MouseButtons  m_buttons   = Qt::NoButton;

    // xkbcommon state (opaque to this header to avoid xkbcommon.h leaking)
    struct XkbState;
    XkbState         *m_xkb       = nullptr;
};
