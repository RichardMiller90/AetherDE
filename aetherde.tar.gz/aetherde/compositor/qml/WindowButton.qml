// compositor/qml/WindowButton.qml
// SPDX-License-Identifier: MIT
import QtQuick

Rectangle {
    id: btn
    width: 14; height: 14; radius: 7
    color: accent
    property color accent: "#888"
    signal clicked()

    HoverHandler { id: hover }
    TapHandler   { onTapped: btn.clicked() }

    Rectangle {
        anchors.fill: parent
        radius:       parent.radius
        color:        hover.hovered ? Qt.lighter(accent, 1.3) : "transparent"
    }
}
