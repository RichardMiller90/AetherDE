// compositor/qml/XdgToplevelChrome.qml
// Window decoration + placement chrome for each xdg-toplevel surface
// SPDX-License-Identifier: MIT

import QtQuick
import QtQuick.Controls
import QtWayland.Compositor
import QtWayland.Compositor.XdgShell

Item {
    id: chrome

    required property XdgToplevel toplevel
    required property XdgSurface  shellSurface

    readonly property bool isMaximized  : toplevel.states & XdgToplevel.State.Maximized
    readonly property bool isFullscreen : toplevel.states & XdgToplevel.State.Fullscreen
    readonly property bool isMinimized  : toplevel.states & XdgToplevel.State.Minimized

    // Position managed by compositor / user drag
    x: toplevel.windowGeometry.x
    y: toplevel.windowGeometry.y

    width:  surfaceItem.width  + (isMaximized || isFullscreen ? 0 : 2)
    height: surfaceItem.height + titleBar.height + (isMaximized || isFullscreen ? 0 : 2)

    visible: !isMinimized

    // ── Drop shadow ──────────────────────────────────────────────────────────────
    layer.enabled: !isMaximized && !isFullscreen
    layer.effect: MultiEffect {
        shadowEnabled: true
        shadowColor:   "#80000000"
        shadowBlur:    0.8
        shadowVerticalOffset:   6
        shadowHorizontalOffset: 0
    }

    // ── Title bar ────────────────────────────────────────────────────────────────
    Rectangle {
        id: titleBar
        width:  parent.width
        height: isMaximized || isFullscreen ? 0 : 32
        visible: height > 0
        color:  chrome.activeFocus ? "#2d2d5a" : "#1e1e3a"
        radius: 8

        // Bottom corners square when window is not floating
        Rectangle {
            anchors.bottom: parent.bottom
            anchors.left:   parent.left
            width:  parent.width
            height: parent.radius
            color:  parent.color
        }

        // App icon
        Item {
            id: appIcon
            anchors { left: parent.left; leftMargin: 8; verticalCenter: parent.verticalCenter }
            width: 20; height: 20
            // Loaded dynamically from .desktop file icon lookup (TODO: IconProvider)
        }

        // Title text
        Text {
            anchors.centerIn: parent
            text:  toplevel.title || toplevel.appId || "Window"
            color: "#e0e0ff"
            font { pixelSize: 13; weight: Font.Medium }
            elide: Text.ElideRight
            width: parent.width - 140
        }

        // ── Window buttons ───────────────────────────────────────────────────────
        Row {
            anchors { right: parent.right; rightMargin: 8; verticalCenter: parent.verticalCenter }
            spacing: 6

            // Minimise
            WindowButton { accent: "#f5c518"; onClicked: toplevel.sendMinimized() }
            // Maximise / Restore
            WindowButton { accent: "#44d7b6"
                onClicked: {
                    if (isMaximized) toplevel.sendUnmaximized()
                    else             toplevel.sendMaximized()
                }
            }
            // Close
            WindowButton { accent: "#e74c3c"; onClicked: toplevel.sendClose() }
        }

        // Drag to move
        DragHandler {
            target: chrome
            xAxis.minimum: 0; xAxis.maximum: 99999
            yAxis.minimum: 0; yAxis.maximum: 99999
            onActiveChanged: {
                if (active) shellSurface.startSystemMove()
            }
        }

        // Double-click to maximise
        TapHandler {
            numberOfTapsRequired: 2
            onTapped: {
                if (isMaximized) toplevel.sendUnmaximized()
                else             toplevel.sendMaximized()
            }
        }
    }

    // ── Client surface ───────────────────────────────────────────────────────────
    ShellSurfaceItem {
        id: surfaceItem
        anchors.top:    titleBar.bottom
        anchors.left:   parent.left
        shellSurface:   chrome.shellSurface
        autoCreatePopupItems: true

        onSurfaceDestroyed: chrome.destroy()
        onMouseRelease: chrome.forceActiveFocus()
    }

    // ── Resize handle ────────────────────────────────────────────────────────────
    ResizeHandle { edge: Qt.RightEdge  | Qt.BottomEdge; anchors { right: parent.right; bottom: parent.bottom } }
    ResizeHandle { edge: Qt.RightEdge;  anchors { right: parent.right; top: titleBar.bottom; bottom: parent.bottom } }
    ResizeHandle { edge: Qt.BottomEdge; anchors { bottom: parent.bottom; left: parent.left; right: parent.right } }
    ResizeHandle { edge: Qt.LeftEdge;   anchors { left: parent.left; top: titleBar.bottom; bottom: parent.bottom } }

    // ── Focus ────────────────────────────────────────────────────────────────────
    TapHandler { onTapped: chrome.forceActiveFocus() }
    onActiveFocusChanged: toplevel.activated = activeFocus
}
