// compositor/qml/compositor.qml
// AetherDE – Wayland compositor scene rendered in QML
// SPDX-License-Identifier: MIT

import QtQuick
import QtQuick.Window
import QtWayland.Compositor
import QtWayland.Compositor.XdgShell
import QtWayland.Compositor.WlShell

WaylandCompositor {
    id: waylandCompositor

    // ── Shell protocols ────────────────────────────────────────────────────────
    XdgShell {
        onToplevelCreated: (toplevel, xdgSurface) => {
            var component = Qt.createComponent("XdgToplevelChrome.qml")
            var chrome = component.createObject(defaultOutput.surfaceArea, {
                "shellSurface": xdgSurface,
                "toplevel":     toplevel
            })
        }
    }

    // ── Default output ─────────────────────────────────────────────────────────
    WaylandOutput {
        id: defaultOutput
        compositor: waylandCompositor
        window: outputWindow

        property alias surfaceArea: surfaceArea
    }

    // ── Render window ──────────────────────────────────────────────────────────
    Window {
        id: outputWindow
        flags: Qt.FramelessWindowHint | Qt.WindowStaysOnBottomHint
        visibility: Window.FullScreen
        color: "#1a1a2e"    // dark navy desktop background

        // Wallpaper layer
        Rectangle {
            id: wallpaper
            anchors.fill: parent
            gradient: Gradient {
                orientation: Gradient.Vertical
                GradientStop { position: 0.0; color: "#0f0f1a" }
                GradientStop { position: 1.0; color: "#1a1a3a" }
            }
        }

        // Surface area – regular windows land here
        Item {
            id: surfaceArea
            anchors.fill: parent
        }

        // Cursor
        WaylandCursorItem {
            id: cursor
            inputEventsEnabled: false
            visible: true
        }
    }

    // ── Pointer handling ───────────────────────────────────────────────────────
    WaylandSeat {
        id: defaultSeat
        drag.target: dragIcon
    }

    Item { id: dragIcon }
}
