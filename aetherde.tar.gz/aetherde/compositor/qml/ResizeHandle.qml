// compositor/qml/ResizeHandle.qml
// SPDX-License-Identifier: MIT
import QtQuick
import QtWayland.Compositor.XdgShell

Item {
    id: handle
    required property int edge
    width:  (edge & (Qt.LeftEdge | Qt.RightEdge)) ? 6 : parent.width
    height: (edge & (Qt.TopEdge | Qt.BottomEdge)) ? 6 : parent.height

    DragHandler {
        cursorShape: {
            switch (edge) {
            case Qt.LeftEdge:                    return Qt.SizeHorCursor
            case Qt.RightEdge:                   return Qt.SizeHorCursor
            case Qt.TopEdge:                     return Qt.SizeVerCursor
            case Qt.BottomEdge:                  return Qt.SizeVerCursor
            case Qt.LeftEdge  | Qt.TopEdge:      return Qt.SizeFDiagCursor
            case Qt.RightEdge | Qt.BottomEdge:   return Qt.SizeFDiagCursor
            case Qt.RightEdge | Qt.TopEdge:      return Qt.SizeBDiagCursor
            case Qt.LeftEdge  | Qt.BottomEdge:   return Qt.SizeBDiagCursor
            default:                             return Qt.ArrowCursor
            }
        }
        onActiveChanged: {
            if (active && chrome.shellSurface)
                chrome.shellSurface.startSystemResize(edge)
        }
    }
}
