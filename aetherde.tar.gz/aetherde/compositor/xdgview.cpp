// compositor/xdgview.cpp
// SPDX-License-Identifier: MIT

#include "xdgview.h"
#include "compositor.h"
#include "output.h"

#include <QWaylandSurface>
#include <QWaylandOutput>
#include <QLoggingCategory>

Q_LOGGING_CATEGORY(lcView, "aether.view")

// ─────────────────────────────────────────────────────────────────────────────
XdgView::XdgView(QWaylandXdgSurface  *xdgSurface,
                 QWaylandXdgToplevel *toplevel,
                 AetherCompositor    *compositor)
    : QObject(compositor)
    , m_compositor(compositor)
    , m_xdgSurface(xdgSurface)
    , m_toplevel(toplevel)
    , m_view(new QWaylandView(compositor, this))
{
    m_view->setSurface(xdgSurface->surface());
    m_view->setOutput(compositor->defaultOutput());

    // Title / appId / state change notifications
    connect(toplevel, &QWaylandXdgToplevel::titleChanged,
            this, [this]() { emit titleChanged(title()); });
    connect(toplevel, &QWaylandXdgToplevel::appIdChanged,
            this, [this]() { emit appIdChanged(appId()); });
    connect(toplevel, &QWaylandXdgToplevel::startedSystemResize,
            this, [this](QWaylandSeat *seat, Qt::Edges edges, quint32 serial) {
                m_compositor->startInteractiveResize(this, seat, serial, edges);
            });
    connect(toplevel, &QWaylandXdgToplevel::startedSystemMove,
            this, [this](QWaylandSeat *seat, quint32 serial) {
                m_compositor->startInteractiveMove(this, seat, serial);
            });
    connect(toplevel, &QWaylandXdgToplevel::statesChanged,
            this, &XdgView::onToplevelStateChanged);

    connect(xdgSurface->surface(), &QWaylandSurface::damaged,
            this, &XdgView::onSurfaceCommitted);

    // When the client destroys its xdg_toplevel, delete this view
    connect(toplevel, &QWaylandXdgToplevel::destroyed,
            this,     &XdgView::deleteLater);

    qCDebug(lcView) << "View created for" << appId() << "/" << title();
}

XdgView::~XdgView()
{
    qCDebug(lcView) << "View destroyed for" << appId();
}

// ─────────────────────────────────────────────────────────────────────────────
QSize XdgView::size() const
{
    if (!m_xdgSurface || !m_xdgSurface->surface())
        return {};
    return m_xdgSurface->surface()->destinationSize();
}

void XdgView::setPosition(const QPoint &pos)
{
    if (m_position == pos) return;
    m_position = pos;
    emit geometryChanged();
}

// ─────────────────────────────────────────────────────────────────────────────
void XdgView::activate()
{
    if (m_minimized) {
        m_minimized = false;
        emit stateChanged();
    }
    if (!m_activated) {
        m_activated = true;
        m_toplevel->sendActivated(true);
        emit activatedChanged(true);
    }
    m_view->setSurface(m_xdgSurface->surface());
}

void XdgView::deactivate()
{
    if (m_activated) {
        m_activated = false;
        m_toplevel->sendActivated(false);
        emit activatedChanged(false);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
void XdgView::maximize(const QRect &available)
{
    if (m_maximized) return;
    m_savedGeometry = geometry();
    m_maximized     = true;
    m_toplevel->sendMaximized(available.size());
    setPosition(available.topLeft());
    emit stateChanged();
}

void XdgView::unmaximize()
{
    if (!m_maximized) return;
    m_maximized = false;
    m_toplevel->sendUnmaximized(m_savedGeometry.size());
    setPosition(m_savedGeometry.topLeft());
    emit stateChanged();
}

void XdgView::requestFullscreen(bool on)
{
    if (on == m_fullscreen) return;
    if (on) {
        if (!m_fullscreen) m_savedGeometry = geometry();
        const QRect screen = m_compositor->primaryOutput()
                           ? m_compositor->primaryOutput()->screen()->geometry()
                           : QRect(0, 0, 1920, 1080);
        m_fullscreen = true;
        m_toplevel->sendFullscreen(screen.size());
        setPosition(screen.topLeft());
    } else {
        m_fullscreen = false;
        m_toplevel->sendUnmaximized(m_savedGeometry.size());
        setPosition(m_savedGeometry.topLeft());
    }
    emit stateChanged();
}

void XdgView::minimize()
{
    if (m_minimized) return;
    m_minimized = true;
    deactivate();
    emit stateChanged();
}

void XdgView::close()
{
    m_toplevel->sendClose();
}

// ─────────────────────────────────────────────────────────────────────────────
QString XdgView::title() const
{
    return m_toplevel ? m_toplevel->title() : QString{};
}

QString XdgView::appId() const
{
    return m_toplevel ? m_toplevel->appId() : QString{};
}

// ─────────────────────────────────────────────────────────────────────────────
void XdgView::onToplevelStateChanged()
{
    emit stateChanged();
    emit geometryChanged();
}

void XdgView::onSurfaceCommitted()
{
    emit geometryChanged();
}
