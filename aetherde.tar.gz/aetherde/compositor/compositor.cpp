// compositor/compositor.cpp
// SPDX-License-Identifier: MIT

#include "compositor.h"
#include "output.h"
#include "xdgview.h"
#include "layershell.h"
#include "inputmanager.h"

#include <QWaylandOutput>
#include <QWaylandSurface>
#include <QWaylandXdgShell>
#include <QWaylandXdgToplevel>
#include <QWaylandXdgPopup>
#include <QWaylandSeat>
#include <QGuiApplication>
#include <QScreen>
#include <QLoggingCategory>

Q_LOGGING_CATEGORY(lcCompositor, "aether.compositor")

// ─────────────────────────────────────────────────────────────────────────────
AetherCompositor::AetherCompositor(QObject *parent)
    : QWaylandCompositor(parent)
{
}

AetherCompositor::~AetherCompositor() = default;

// ─────────────────────────────────────────────────────────────────────────────
void AetherCompositor::create()
{
    // Let Qt Wayland create the core Wayland global objects (wl_compositor,
    // wl_shm, wl_subcompositor, wp_presentation …).
    QWaylandCompositor::create();

    // ── xdg-shell ─────────────────────────────────────────────────────────────
    m_xdgShell = new QWaylandXdgShell(this);
    connect(m_xdgShell, &QWaylandXdgShell::toplevelCreated,
            this, &AetherCompositor::onToplevelCreated);

    // ── wlr-layer-shell ───────────────────────────────────────────────────────
    m_layerShell = new LayerShellManager(this);

    // ── Input ─────────────────────────────────────────────────────────────────
    m_input = new InputManager(this);

    // ── Outputs ───────────────────────────────────────────────────────────────
    for (QScreen *screen : QGuiApplication::screens()) {
        auto *output = new Output(this, screen);
        setupOutput(output);
    }

    // Dynamic screen add/remove (multi-monitor hotplug)
    connect(qGuiApp, &QGuiApplication::screenAdded, this, [this](QScreen *screen) {
        auto *output = new Output(this, screen);
        setupOutput(output);
    });
    connect(qGuiApp, &QGuiApplication::screenRemoved, this, [this](QScreen *screen) {
        m_outputs.removeIf([&](Output *o) { return o->screen() == screen; });
    });

    // Surface life-cycle
    connect(this, &QWaylandCompositor::surfaceCreated,
            this, &AetherCompositor::onSurfaceCreated);

    qCInfo(lcCompositor) << "AetherDE compositor ready on"
                         << m_outputs.size() << "output(s)";
}

// ─────────────────────────────────────────────────────────────────────────────
void AetherCompositor::setupOutput(Output *output)
{
    m_outputs.append(output);
    emit outputAdded(output);
    qCInfo(lcCompositor) << "Output added:" << output->screen()->name()
                         << output->screen()->geometry();
}

// ─────────────────────────────────────────────────────────────────────────────
void AetherCompositor::onSurfaceCreated(QWaylandSurface *surface)
{
    connect(surface, &QWaylandSurface::hasContentChanged, this, [surface, this]() {
        if (!surface->hasContent())
            qCDebug(lcCompositor) << "Surface lost content:" << surface;
    });
}

void AetherCompositor::onSurfaceDestroyed(QWaylandSurface *surface)
{
    Q_UNUSED(surface)
}

// ─────────────────────────────────────────────────────────────────────────────
void AetherCompositor::onToplevelCreated(QWaylandXdgToplevel *toplevel,
                                          QWaylandXdgSurface  *xdgSurface)
{
    auto *view = new XdgView(xdgSurface, toplevel, this);
    m_views.append(view);

    connect(view, &XdgView::destroyed, this, [this, view]() {
        onToplevelDestroyed(view);
    });

    // Place new window at screen centre of the primary output
    if (!m_outputs.isEmpty()) {
        const QRect screen = m_outputs.first()->screen()->geometry();
        const QSize hint   = toplevel->maxSize().isEmpty()
                           ? QSize(800, 600)
                           : toplevel->maxSize();
        const QPoint pos   = screen.center() - QPoint(hint.width()/2, hint.height()/2);
        view->setPosition(pos);
    }

    setActiveView(view);
    emit viewAdded(view);

    qCDebug(lcCompositor) << "Toplevel created:"
                          << toplevel->appId() << toplevel->title();
}

void AetherCompositor::onToplevelDestroyed(XdgView *view)
{
    removeView(view);
}

// ─────────────────────────────────────────────────────────────────────────────
void AetherCompositor::removeView(XdgView *view)
{
    const int idx = m_views.indexOf(view);
    if (idx < 0) return;
    m_views.removeAt(idx);

    if (m_activeView == view) {
        // Activate the window that was just below this one
        m_activeView = m_views.isEmpty() ? nullptr : m_views.last();
        if (m_activeView)
            m_activeView->activate();
        emit activeViewChanged(m_activeView);
    }

    emit viewRemoved(view);
}

// ─────────────────────────────────────────────────────────────────────────────
void AetherCompositor::raiseView(XdgView *view)
{
    if (m_views.isEmpty()) return;
    const int idx = m_views.indexOf(view);
    if (idx < 0) return;
    m_views.removeAt(idx);
    m_views.append(view);        // topmost (last) = rendered last = on top

    setActiveView(view);
}

// ─────────────────────────────────────────────────────────────────────────────
void AetherCompositor::setActiveView(XdgView *view)
{
    if (m_activeView == view) return;

    if (m_activeView)
        m_activeView->deactivate();

    m_activeView = view;

    if (m_activeView) {
        m_activeView->activate();
        raiseView(m_activeView); // keep stacking and focus in sync
    }

    emit activeViewChanged(m_activeView);
}

// ─────────────────────────────────────────────────────────────────────────────
XdgView *AetherCompositor::viewAt(const QPointF &globalPos) const
{
    // Iterate from topmost to bottommost
    for (int i = m_views.size() - 1; i >= 0; --i) {
        XdgView *v = m_views[i];
        if (v->geometry().contains(globalPos.toPoint()))
            return v;
    }
    return nullptr;
}

// ─────────────────────────────────────────────────────────────────────────────
Output *AetherCompositor::primaryOutput() const
{
    return m_outputs.isEmpty() ? nullptr : m_outputs.first();
}

// ─────────────────────────────────────────────────────────────────────────────
void AetherCompositor::startInteractiveMove(XdgView *view,
                                             QWaylandSeat *seat,
                                             quint32 serial)
{
    if (!view || !seat) return;
    view->xdgSurface()->toplevel()->startMove(seat, serial);
}

void AetherCompositor::startInteractiveResize(XdgView *view,
                                               QWaylandSeat *seat,
                                               quint32 serial,
                                               Qt::Edges edges)
{
    if (!view || !seat) return;
    view->xdgSurface()->toplevel()->startResize(seat, serial, edges);
}

// ─────────────────────────────────────────────────────────────────────────────
void AetherCompositor::requestQuit()
{
    qCInfo(lcCompositor) << "Compositor shutting down";
    QCoreApplication::quit();
}

void AetherCompositor::onSubsurfaceChanged(QWaylandSurface *child,
                                            QWaylandSurface *parent)
{
    Q_UNUSED(child); Q_UNUSED(parent);
}
