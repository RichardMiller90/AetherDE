// compositor/inputmanager.cpp
// SPDX-License-Identifier: MIT

#include "inputmanager.h"
#include "compositor.h"
#include "xdgview.h"

#include <QWaylandSeat>
#include <QWaylandPointer>
#include <QWaylandKeyboard>
#include <QWaylandSurface>
#include <QScreen>
#include <QGuiApplication>
#include <QLoggingCategory>

extern "C" {
#include <libinput.h>
#include <libudev.h>
#include <xkbcommon/xkbcommon.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
}

Q_LOGGING_CATEGORY(lcInput, "aether.input")

// ── libinput open/close callbacks ─────────────────────────────────────────────
static int li_open(const char *path, int flags, void *)
{
    return open(path, flags | O_CLOEXEC);
}
static void li_close(int fd, void *)
{
    close(fd);
}
static const struct libinput_interface s_li_iface = { li_open, li_close };

// ─────────────────────────────────────────────────────────────────────────────
struct InputManager::XkbState
{
    struct xkb_context *ctx  = nullptr;
    struct xkb_keymap  *map  = nullptr;
    struct xkb_state   *state = nullptr;

    XkbState() {
        ctx = xkb_context_new(XKB_CONTEXT_NO_FLAGS);
        const struct xkb_rule_names names = {};
        map   = xkb_keymap_new_from_names(ctx, &names, XKB_KEYMAP_COMPILE_NO_FLAGS);
        state = xkb_state_new(map);
    }
    ~XkbState() {
        if (state) xkb_state_unref(state);
        if (map)   xkb_keymap_unref(map);
        if (ctx)   xkb_context_unref(ctx);
    }
};

// ─────────────────────────────────────────────────────────────────────────────
InputManager::InputManager(AetherCompositor *compositor)
    : QObject(compositor)
    , m_compositor(compositor)
    , m_xkb(new XkbState)
{
    // Create the Wayland seat
    m_seat = new QWaylandSeat(compositor, QWaylandSeat::Pointer
                                        | QWaylandSeat::Keyboard
                                        | QWaylandSeat::Touch);
    m_seat->setName(QStringLiteral("seat0"));

    // Init libinput with udev backend (enumerates all input devices)
    struct udev *udev = udev_new();
    if (!udev) {
        qCWarning(lcInput) << "Failed to create udev context";
        return;
    }
    m_li = libinput_udev_create_context(&s_li_iface, nullptr, udev);
    udev_unref(udev);
    if (!m_li) {
        qCWarning(lcInput) << "Failed to create libinput context";
        return;
    }
    if (libinput_udev_assign_seat(m_li, "seat0") != 0) {
        qCWarning(lcInput) << "Failed to assign seat0 to libinput";
        return;
    }

    // Poll libinput fd from Qt's event loop
    const int fd = libinput_get_fd(m_li);
    auto *notifier = new QSocketNotifier(fd, QSocketNotifier::Read, this);
    connect(notifier, &QSocketNotifier::activated, this, [this]() {
        libinput_dispatch(m_li);
        processEvents();
    });

    qCInfo(lcInput) << "Input manager ready (libinput + xkbcommon)";
}

InputManager::~InputManager()
{
    if (m_li) libinput_unref(m_li);
    delete m_xkb;
}

// ─────────────────────────────────────────────────────────────────────────────
void InputManager::processEvents()
{
    if (!m_li) return;
    libinput_dispatch(m_li);
    libinput_event *ev;
    while ((ev = libinput_get_event(m_li)) != nullptr) {
        switch (libinput_event_get_type(ev)) {
        case LIBINPUT_EVENT_POINTER_MOTION:
        case LIBINPUT_EVENT_POINTER_MOTION_ABSOLUTE:
            handlePointerMotion(ev);
            break;
        case LIBINPUT_EVENT_POINTER_BUTTON:
            handlePointerButton(ev);
            break;
        case LIBINPUT_EVENT_POINTER_AXIS:
        case LIBINPUT_EVENT_POINTER_SCROLL_WHEEL:
        case LIBINPUT_EVENT_POINTER_SCROLL_FINGER:
            handlePointerAxis(ev);
            break;
        case LIBINPUT_EVENT_KEYBOARD_KEY:
            handleKeyboard(ev);
            break;
        case LIBINPUT_EVENT_TOUCH_DOWN:
        case LIBINPUT_EVENT_TOUCH_UP:
        case LIBINPUT_EVENT_TOUCH_MOTION:
            handleTouch(ev);
            break;
        default:
            break;
        }
        libinput_event_destroy(ev);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
void InputManager::handlePointerMotion(libinput_event *ev)
{
    const QSize screenSize = QGuiApplication::primaryScreen()
                           ? QGuiApplication::primaryScreen()->geometry().size()
                           : QSize(1920, 1080);

    const auto type = libinput_event_get_type(ev);
    if (type == LIBINPUT_EVENT_POINTER_MOTION) {
        auto *pe = libinput_event_get_pointer_event(ev);
        double dx = libinput_event_pointer_get_dx(pe);
        double dy = libinput_event_pointer_get_dy(pe);
        m_pointerPos += QPointF(dx, dy);
    } else {
        auto *pe = libinput_event_get_pointer_event(ev);
        double ax = libinput_event_pointer_get_absolute_x_transformed(pe, screenSize.width());
        double ay = libinput_event_pointer_get_absolute_y_transformed(pe, screenSize.height());
        m_pointerPos = QPointF(ax, ay);
    }

    // Clamp to screen bounds
    m_pointerPos.setX(qBound(0.0, m_pointerPos.x(), (double)(screenSize.width()  - 1)));
    m_pointerPos.setY(qBound(0.0, m_pointerPos.y(), (double)(screenSize.height() - 1)));

    emit pointerMoved(m_pointerPos);

    // Route to the focused Wayland surface
    XdgView *view = m_compositor->viewAt(m_pointerPos);
    if (view && view->xdgSurface() && view->xdgSurface()->surface()) {
        const QPointF local = m_pointerPos - QPointF(view->position());
        m_seat->sendMouseMoveEvent(m_seat->mouseFocusSurface()
                                 ? m_seat->mouseFocusSurface()
                                 : nullptr,
                                 local, m_pointerPos);
    }
}

void InputManager::handlePointerButton(libinput_event *ev)
{
    auto *pe     = libinput_event_get_pointer_event(ev);
    uint32_t btn = libinput_event_pointer_get_button(pe);
    bool pressed = libinput_event_pointer_get_button_state(pe)
                 == LIBINPUT_BUTTON_STATE_PRESSED;

    // Map Linux button codes to Qt
    Qt::MouseButton qtBtn = Qt::NoButton;
    switch (btn) {
    case 0x110: qtBtn = Qt::LeftButton;  break;
    case 0x111: qtBtn = Qt::RightButton; break;
    case 0x112: qtBtn = Qt::MiddleButton; break;
    default:    qtBtn = Qt::ExtraButton1; break;
    }

    if (pressed)  m_buttons |=  qtBtn;
    else          m_buttons &= ~qtBtn;

    // Focus the window under the pointer on left-press
    if (pressed && qtBtn == Qt::LeftButton) {
        XdgView *view = m_compositor->viewAt(m_pointerPos);
        if (view) m_compositor->setActiveView(view);
    }

    m_seat->sendMousePressEvent(qtBtn);
    emit pointerButton(qtBtn, pressed, m_pointerPos);
}

void InputManager::handlePointerAxis(libinput_event *ev)
{
    auto *pe = libinput_event_get_pointer_event(ev);
    Q_UNUSED(pe)
    // Scroll: forwarded via QWaylandSeat::sendMouseWheelEvent
}

void InputManager::handleKeyboard(libinput_event *ev)
{
    if (!m_xkb || !m_xkb->state) return;
    auto *ke = libinput_event_get_keyboard_event(ev);
    uint32_t key = libinput_event_keyboard_get_key(ke);
    bool pressed = libinput_event_keyboard_get_key_state(ke)
                 == LIBINPUT_KEY_STATE_PRESSED;

    // Update xkbcommon state
    xkb_state_update_key(m_xkb->state, key + 8,
                         pressed ? XKB_KEY_DOWN : XKB_KEY_UP);

    const xkb_keysym_t sym = xkb_state_key_get_one_sym(m_xkb->state, key + 8);
    char buf[32];
    xkb_keysym_to_utf8(sym, buf, sizeof(buf));

    Qt::KeyboardModifiers mods;
    if (xkb_state_mod_name_is_active(m_xkb->state, XKB_MOD_NAME_SHIFT, XKB_STATE_MODS_EFFECTIVE))
        mods |= Qt::ShiftModifier;
    if (xkb_state_mod_name_is_active(m_xkb->state, XKB_MOD_NAME_CTRL,  XKB_STATE_MODS_EFFECTIVE))
        mods |= Qt::ControlModifier;
    if (xkb_state_mod_name_is_active(m_xkb->state, XKB_MOD_NAME_ALT,   XKB_STATE_MODS_EFFECTIVE))
        mods |= Qt::AltModifier;
    if (xkb_state_mod_name_is_active(m_xkb->state, XKB_MOD_NAME_LOGO,  XKB_STATE_MODS_EFFECTIVE))
        mods |= Qt::MetaModifier;

    emit keyEvent(static_cast<int>(sym), mods, pressed, QString::fromUtf8(buf));

    // Send to focused Wayland client
    if (m_seat->keyboardFocus())
        m_seat->sendKeyEvent(key, pressed);
}

void InputManager::handleTouch(libinput_event *ev)
{
    Q_UNUSED(ev)
    emit touchEvent();
}
