// compositor/main.cpp  –  AetherDE Wayland Compositor
// SPDX-License-Identifier: MIT

#include "compositor.h"
#include "output.h"

#include <QGuiApplication>
#include <QQuickView>
#include <QWaylandQuickCompositor>
#include <QWaylandQuickOutput>
#include <QQmlEngine>
#include <QQmlContext>
#include <QDBusConnection>
#include <QDBusInterface>
#include <QCommandLineParser>
#include <QLoggingCategory>
#include <QDir>
#include <cstdlib>

Q_LOGGING_CATEGORY(lcMain, "aether.main")

static void setEnvironment()
{
    // Force Wayland platform plugin for Qt apps launched inside the compositor
    qputenv("QT_QPA_PLATFORM",       "wayland");
    qputenv("GDK_BACKEND",           "wayland");
    qputenv("CLUTTER_BACKEND",       "wayland");
    qputenv("SDL_VIDEODRIVER",       "wayland");
    qputenv("MOZ_ENABLE_WAYLAND",    "1");
    qputenv("_JAVA_AWT_WM_NONREPARENTING", "1");

    // DRM/EGL backend
    if (qEnvironmentVariableIsEmpty("WLR_RENDERER"))
        qputenv("WLR_RENDERER", "auto");
}

// ─────────────────────────────────────────────────────────────────────────────
int main(int argc, char *argv[])
{
    // Must set before QGuiApplication is constructed
    qputenv("QT_QPA_PLATFORM", "wayland-egl");   // run as compositor
    qputenv("QT_WAYLAND_DISABLE_WINDOWDECORATION", "1");

    QGuiApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("AetherDE Compositor"));
    app.setApplicationVersion(AETHER_VERSION);
    app.setOrganizationName(QStringLiteral("AetherDE"));

    QCommandLineParser parser;
    parser.setApplicationDescription("AetherDE Wayland Compositor");
    parser.addHelpOption();
    parser.addVersionOption();
    QCommandLineOption socketOpt({"s","socket"}, "Wayland socket name", "socket", "wayland-aether");
    parser.addOption(socketOpt);
    QCommandLineOption startupOpt("startup", "Run command after compositor is ready", "cmd");
    parser.addOption(startupOpt);
    parser.process(app);

    // Wayland socket name
    const QString socketName = parser.value(socketOpt);
    qputenv("WAYLAND_DISPLAY", socketName.toUtf8());

    setEnvironment();

    // ── Compositor ─────────────────────────────────────────────────────────────
    AetherCompositor compositor;
    compositor.setSocketName(socketName.toUtf8());
    compositor.create();

    // ── QML compositor view (renders surfaces into a QQuickWindow) ─────────────
    QQuickView view;
    view.setResizeMode(QQuickView::SizeRootObjectToView);
    view.engine()->rootContext()->setContextProperty("compositor", &compositor);
    view.engine()->rootContext()->setContextProperty(
        "dataDir", QString::fromUtf8(AETHER_DATADIR));

    const QString qmlMain = QStringLiteral(AETHER_DATADIR) + "/compositor/compositor.qml";
    const QString qmlDev  = QStringLiteral(SOURCE_DIR "/compositor/qml/compositor.qml");

    // Prefer installed QML; fall back to build-tree for development
    if (QFile::exists(qmlMain))
        view.setSource(QUrl::fromLocalFile(qmlMain));
    else if (QFile::exists(qmlDev))
        view.setSource(QUrl::fromLocalFile(qmlDev));
    else
        view.setSource(QUrl(QStringLiteral("qrc:/compositor/compositor.qml")));

    view.showFullScreen();

    // ── Launch shell and startup command after compositor is up ────────────────
    QTimer::singleShot(500, [&] {
        // Launch the AetherDE shell as a Wayland client
        QProcess::startDetached("aether-shell", {});
        // User-supplied startup command (optional)
        const QString startup = parser.value(startupOpt);
        if (!startup.isEmpty())
            QProcess::startDetached("sh", {"-c", startup});
    });

    qCInfo(lcMain) << "Compositor running on socket:" << socketName;
    return app.exec();
}
