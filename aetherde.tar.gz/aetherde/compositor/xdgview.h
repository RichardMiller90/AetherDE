#pragma once
// compositor/xdgview.h
// SPDX-License-Identifier: MIT

#include <QObject>
#include <QRect>
#include <QPoint>
#include <QSize>
#include <QWaylandXdgSurface>
#include <QWaylandXdgToplevel>
#include <QWaylandView>

class AetherCompositor;

// ─────────────────────────────────────────────────────────────────────────────
// XdgView wraps a QWaylandXdgToplevel and tracks geometry / focus state as
// seen by the compositor.  One view = one application window.
// ─────────────────────────────────────────────────────────────────────────────
class XdgView : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QPoint  position READ position  WRITE setPosition  NOTIFY geometryChanged)
    Q_PROPERTY(QSize   size     READ size                         NOTIFY geometryChanged)
    Q_PROPERTY(bool    activated READ isActivated                 NOTIFY activatedChanged)
    Q_PROPERTY(bool    maximized READ isMaximized                 NOTIFY stateChanged)
    Q_PROPERTY(bool    fullscreen READ isFullscreen               NOTIFY stateChanged)
    Q_PROPERTY(bool    minimized READ isMinimized                 NOTIFY stateChanged)
    Q_PROPERTY(QString title    READ title                        NOTIFY titleChanged)
    Q_PROPERTY(QString appId    READ appId                        NOTIFY appIdChanged)

public:
    explicit XdgView(QWaylandXdgSurface  *xdgSurface,
                     QWaylandXdgToplevel *toplevel,
                     AetherCompositor    *compositor);
    ~XdgView() override;

    // ── Geometry ──────────────────────────────────────────────────────────────
    QPoint position()   const { return m_position; }
    QSize  size()       const;
    QRect  geometry()   const { return QRect(m_position, size()); }

    void   setPosition(const QPoint &pos);
    void   move(const QPoint &delta) { setPosition(m_position + delta); }

    // ── Focus / state ─────────────────────────────────────────────────────────
    bool isActivated()  const { return m_activated;  }
    bool isMaximized()  const { return m_maximized;  }
    bool isFullscreen() const { return m_fullscreen; }
    bool isMinimized()  const { return m_minimized;  }

    void activate();
    void deactivate();
    void maximize(const QRect &available);
    void unmaximize();
    void requestFullscreen(bool on);
    void minimize();
    void close();

    // ── Meta ──────────────────────────────────────────────────────────────────
    QString title() const;
    QString appId() const;

    QWaylandXdgSurface  *xdgSurface() const { return m_xdgSurface; }
    QWaylandXdgToplevel *toplevel()   const { return m_toplevel;   }
    QWaylandView        *view()       const { return m_view;        }

signals:
    void geometryChanged();
    void activatedChanged(bool activated);
    void stateChanged();
    void titleChanged(const QString &title);
    void appIdChanged(const QString &appId);

private slots:
    void onToplevelStateChanged();
    void onSurfaceCommitted();

private:
    AetherCompositor    *m_compositor;
    QWaylandXdgSurface  *m_xdgSurface;
    QWaylandXdgToplevel *m_toplevel;
    QWaylandView        *m_view;

    QPoint  m_position;
    QRect   m_savedGeometry;   // before maximise/fullscreen
    bool    m_activated  = false;
    bool    m_maximized  = false;
    bool    m_fullscreen = false;
    bool    m_minimized  = false;
};
