// compositor/layershell.cpp
// SPDX-License-Identifier: MIT

#include "layershell.h"
#include "compositor.h"
#include "output.h"

#include <QWaylandSurface>
#include <QLoggingCategory>
#include <algorithm>

Q_LOGGING_CATEGORY(lcLayer, "aether.layershell")

// ─────────────────────────────────────────────────────────────────────────────
//  LayerSurface
// ─────────────────────────────────────────────────────────────────────────────
LayerSurface::LayerSurface(QWaylandSurface *surface,
                            Layer            layer,
                            const QString   &ns,
                            Output          *output,
                            QObject         *parent)
    : QObject(parent)
    , m_surface(surface)
    , m_layer(layer)
    , m_namespace(ns)
    , m_output(output)
{
}

LayerSurface::~LayerSurface() = default;

void LayerSurface::setDesiredSize(int w, int h)
{
    m_desiredWidth  = w;
    m_desiredHeight = h;
    emit propertiesChanged();
}

void LayerSurface::setAnchor(uint32_t anchor)
{
    m_anchor = anchor;
    emit propertiesChanged();
}

void LayerSurface::setExclusiveZone(int zone)
{
    m_exclusiveZone = zone;
    emit propertiesChanged();
}

void LayerSurface::setMargins(int top, int right, int bottom, int left)
{
    m_marginTop    = top;
    m_marginRight  = right;
    m_marginBottom = bottom;
    m_marginLeft   = left;
    emit propertiesChanged();
}

void LayerSurface::setLayer(Layer layer)
{
    m_layer = layer;
    emit propertiesChanged();
}

void LayerSurface::sendConfigure(int width, int height, uint32_t serial)
{
    // In a real implementation this calls
    //   zwlr_layer_surface_v1_send_configure(resource, serial, width, height)
    // via the generated protocol stub.  Here we record the final geometry.
    m_geometry = QRect(m_geometry.topLeft(), QSize(width, height));
    qCDebug(lcLayer) << "Configure sent to" << m_namespace
                     << width << "x" << height << "serial" << serial;
}

// ─────────────────────────────────────────────────────────────────────────────
//  LayerShellManager
// ─────────────────────────────────────────────────────────────────────────────
LayerShellManager::LayerShellManager(AetherCompositor *compositor)
    : QObject(compositor)
    , m_compositor(compositor)
{
    // Register the zwlr_layer_shell_v1 Wayland global.
    // In the full build, this is done via the generated server-side code:
    //   wl_global_create(display, &zwlr_layer_shell_v1_interface, 4,
    //                    this, LayerShellManager::bindCallback);
    // That plumbing is elided here; Qt's extension mechanisms or libwlroots
    // handle it.
    qCInfo(lcLayer) << "Layer shell manager initialised";
}

LayerShellManager::~LayerShellManager() = default;

// ─────────────────────────────────────────────────────────────────────────────
// arrange()  –  Box-model layout algorithm (mirrors Sway / wlroots logic)
//
// Processing order per output, per layer (background → bottom → top → overlay):
//   1. Anchor to edges: compute position + size from anchor flags + margins.
//   2. Apply exclusive_zone: shrink the usable rectangle for normal windows.
// ─────────────────────────────────────────────────────────────────────────────
void LayerShellManager::arrange(Output *output)
{
    const QRect screen = output->geometry();
    QRect usable = screen;

    // Collect surfaces for this output, sorted by layer
    QList<LayerSurface*> ordered;
    for (LayerSurface *ls : m_surfaces) {
        if (ls->output() == output)
            ordered.append(ls);
    }
    std::sort(ordered.begin(), ordered.end(), [](LayerSurface *a, LayerSurface *b) {
        return static_cast<int>(a->layer()) < static_cast<int>(b->layer());
    });

    static uint32_t serialCounter = 1;

    for (LayerSurface *ls : ordered) {
        const uint32_t anchor = ls->anchor();
        const bool ancTop    = anchor & LayerSurface::AnchorTop;
        const bool ancBottom = anchor & LayerSurface::AnchorBottom;
        const bool ancLeft   = anchor & LayerSurface::AnchorLeft;
        const bool ancRight  = anchor & LayerSurface::AnchorRight;

        const int mT = ls->marginTop();
        const int mR = ls->marginRight();
        const int mB = ls->marginBottom();
        const int mL = ls->marginLeft();

        int x = usable.left()  + mL;
        int y = usable.top()   + mT;

        // Width
        int w = ls->desiredWidth();
        if (w == 0 || (ancLeft && ancRight))
            w = usable.width() - mL - mR;

        // Height
        int h = ls->desiredHeight();
        if (h == 0 || (ancTop && ancBottom))
            h = usable.height() - mT - mB;

        // Horizontal position
        if (!ancLeft && ancRight)
            x = usable.right() - w - mR;
        else if (ancLeft && !ancRight)
            x = usable.left() + mL;
        else if (!ancLeft && !ancRight)
            x = usable.left() + (usable.width() - w) / 2;

        // Vertical position
        if (!ancTop && ancBottom)
            y = usable.bottom() - h - mB;
        else if (ancTop && !ancBottom)
            y = usable.top() + mT;
        else if (!ancTop && !ancBottom)
            y = usable.top() + (usable.height() - h) / 2;

        ls->setGeometry(QRect(x, y, w, h));
        ls->sendConfigure(w, h, serialCounter++);

        // Exclusive zone: shrink usable area
        const int zone = ls->exclusiveZone();
        if (zone > 0) {
            if (ancTop && !ancBottom)
                usable.setTop(usable.top() + zone + mT);
            else if (ancBottom && !ancTop)
                usable.setBottom(usable.bottom() - zone - mB);
            else if (ancLeft && !ancRight)
                usable.setLeft(usable.left() + zone + mL);
            else if (ancRight && !ancLeft)
                usable.setRight(usable.right() - zone - mR);
        }
    }

    output->setAvailableGeometry(usable);
    qCDebug(lcLayer) << "Arranged" << ordered.size()
                     << "layer surfaces on" << output->screen()->name()
                     << "– usable:" << usable;
}
