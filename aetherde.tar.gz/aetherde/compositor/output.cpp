// compositor/output.cpp
// SPDX-License-Identifier: MIT

#include "output.h"
#include "compositor.h"

#include <QWaylandOutput>
#include <QScreen>
#include <QLoggingCategory>

Q_LOGGING_CATEGORY(lcOutput, "aether.output")

// ─────────────────────────────────────────────────────────────────────────────
Output::Output(AetherCompositor *compositor, QScreen *screen)
    : QObject(compositor)
    , m_compositor(compositor)
    , m_screen(screen)
    , m_available(screen->geometry())
{
    m_wlOutput = new QWaylandOutput(compositor, nullptr);
    m_wlOutput->setPosition(screen->geometry().topLeft());

    QWaylandOutputMode mode(screen->geometry().size(),
                            static_cast<int>(screen->refreshRate() * 1000));
    m_wlOutput->addMode(mode, /*preferred=*/true);
    m_wlOutput->setCurrentMode(mode);

    // Keep Wayland output in sync when the screen geometry changes
    connect(screen, &QScreen::geometryChanged, this, [this](const QRect &r) {
        m_wlOutput->setPosition(r.topLeft());
        QWaylandOutputMode m(r.size(), static_cast<int>(m_screen->refreshRate() * 1000));
        m_wlOutput->addMode(m, true);
        m_wlOutput->setCurrentMode(m);
        if (m_available == geometry())
            setAvailableGeometry(r);
        qCDebug(lcOutput) << "Screen geometry updated:" << r;
    });

    qCInfo(lcOutput) << "Output created on" << screen->name() << screen->geometry();
}

Output::~Output() = default;

// ─────────────────────────────────────────────────────────────────────────────
QRect Output::geometry() const
{
    return m_screen->geometry();
}

void Output::setAvailableGeometry(const QRect &r)
{
    if (m_available == r) return;
    m_available = r;
    emit availableGeometryChanged(r);
}

// ─────────────────────────────────────────────────────────────────────────────
void Output::scheduleRender()
{
    // Trigger a repaint on this output's window.  The actual render pass is
    // handled by the compositor's QWaylandOutput / QWaylandQuickCompositor
    // render loop — this is a no-op placeholder for custom DRM/EGL backends.
    m_wlOutput->update();
}

void Output::render()
{
    m_compositor->startRender();
    // … custom EGL/DRM render path would go here in a DRM-only backend …
    m_compositor->endRender();
}
