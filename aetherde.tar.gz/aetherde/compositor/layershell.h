#pragma once
// compositor/layershell.h  –  server-side wlr-layer-shell-v1 implementation
// SPDX-License-Identifier: MIT

#include <QObject>
#include <QRect>
#include <QList>

// Forward declare the generated C struct types
struct zwlr_layer_shell_v1;
struct zwlr_layer_surface_v1;
struct wl_client;
struct wl_resource;

class QWaylandSurface;
class AetherCompositor;
class Output;

// ─────────────────────────────────────────────────────────────────────────────
// Represents one layer surface (panel, wallpaper, notification, lock screen)
// created by a shell client.
// ─────────────────────────────────────────────────────────────────────────────
class LayerSurface : public QObject
{
    Q_OBJECT
public:
    enum class Layer {
        Background = 0,
        Bottom     = 1,
        Top        = 2,
        Overlay    = 3,
    };

    enum Anchor : uint32_t {
        AnchorNone   = 0,
        AnchorTop    = (1 << 0),
        AnchorBottom = (1 << 1),
        AnchorLeft   = (1 << 2),
        AnchorRight  = (1 << 3),
    };

    explicit LayerSurface(QWaylandSurface *surface,
                          Layer layer,
                          const QString &ns,
                          Output *output,
                          QObject *parent = nullptr);
    ~LayerSurface() override;

    QWaylandSurface *surface()       const { return m_surface;       }
    Layer            layer()         const { return m_layer;         }
    QString          ns()            const { return m_namespace;     }
    Output          *output()        const { return m_output;        }

    // Desired size (0 = compositor decides)
    int              desiredWidth()  const { return m_desiredWidth;  }
    int              desiredHeight() const { return m_desiredHeight; }

    // Anchor flags
    uint32_t         anchor()        const { return m_anchor;        }

    // How many pixels to reserve (push windows away)
    int              exclusiveZone() const { return m_exclusiveZone; }

    // Margins
    int marginTop()    const { return m_marginTop;    }
    int marginRight()  const { return m_marginRight;  }
    int marginBottom() const { return m_marginBottom; }
    int marginLeft()   const { return m_marginLeft;   }

    void setDesiredSize(int w, int h);
    void setAnchor(uint32_t anchor);
    void setExclusiveZone(int zone);
    void setMargins(int top, int right, int bottom, int left);
    void setLayer(Layer layer);

    // Send a configure event to the client with the committed geometry
    void sendConfigure(int width, int height, uint32_t serial);

    // Computed rect (set by LayerShellManager::arrange())
    QRect geometry() const { return m_geometry; }
    void  setGeometry(const QRect &r) { m_geometry = r; }

signals:
    void propertiesChanged();
    void closed();

private:
    QWaylandSurface *m_surface       = nullptr;
    Layer            m_layer         = Layer::Top;
    QString          m_namespace;
    Output          *m_output        = nullptr;
    int              m_desiredWidth  = 0;
    int              m_desiredHeight = 0;
    uint32_t         m_anchor        = AnchorNone;
    int              m_exclusiveZone = 0;
    int              m_marginTop     = 0;
    int              m_marginRight   = 0;
    int              m_marginBottom  = 0;
    int              m_marginLeft    = 0;
    QRect            m_geometry;
};

// ─────────────────────────────────────────────────────────────────────────────
// LayerShellManager  –  Wayland global, creates LayerSurface objects and
// arranges them on each output.
// ─────────────────────────────────────────────────────────────────────────────
class LayerShellManager : public QObject
{
    Q_OBJECT
public:
    explicit LayerShellManager(AetherCompositor *compositor);
    ~LayerShellManager() override;

    const QList<LayerSurface*>& surfaces() const { return m_surfaces; }

    // Recalculate positions for all layer surfaces on a given output and
    // update the output's available geometry accordingly.
    void arrange(Output *output);

signals:
    void surfaceAdded(LayerSurface *surface);
    void surfaceRemoved(LayerSurface *surface);

private:
    AetherCompositor     *m_compositor;
    QList<LayerSurface*>  m_surfaces;
};
