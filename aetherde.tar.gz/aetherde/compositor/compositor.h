#pragma once
// compositor/compositor.h  –  AetherDE Wayland Compositor
// SPDX-License-Identifier: MIT

#include <QWaylandCompositor>
#include <QWaylandSurface>
#include <QWaylandXdgShell>
#include <QWaylandXdgToplevel>
#include <QWaylandXdgPopup>
#include <QWaylandSeat>
#include <QList>
#include <QHash>
#include <QRect>

class Output;
class XdgView;
class LayerShellManager;
class InputManager;

// ─────────────────────────────────────────────────────────────────────────────
class AetherCompositor : public QWaylandCompositor
{
    Q_OBJECT
    Q_PROPERTY(XdgView* activeView READ activeView WRITE setActiveView NOTIFY activeViewChanged)

public:
    explicit AetherCompositor(QObject *parent = nullptr);
    ~AetherCompositor() override;

    void create() override;

    // Window list (topmost last)
    const QList<XdgView*>& views() const { return m_views; }

    XdgView* activeView() const { return m_activeView; }
    void     setActiveView(XdgView *view);

    XdgView* viewAt(const QPointF &globalPos) const;

    // Raise window to top; activate it
    void raiseView(XdgView *view);

    // Move/resize helpers called by the shell
    void startInteractiveMove(XdgView *view, QWaylandSeat *seat, quint32 serial);
    void startInteractiveResize(XdgView *view, QWaylandSeat *seat, quint32 serial,
                                Qt::Edges edges);

    Output           *primaryOutput()   const;
    LayerShellManager *layerShell()     const { return m_layerShell; }
    InputManager      *inputManager()   const { return m_input; }

    // Ask compositor to exit cleanly
    Q_INVOKABLE void requestQuit();

signals:
    void viewAdded(XdgView *view);
    void viewRemoved(XdgView *view);
    void activeViewChanged(XdgView *view);
    void outputAdded(Output *output);

private slots:
    void onSurfaceCreated(QWaylandSurface *surface);
    void onSurfaceDestroyed(QWaylandSurface *surface);
    void onToplevelCreated(QWaylandXdgToplevel *toplevel,
                           QWaylandXdgSurface  *xdgSurface);
    void onToplevelDestroyed(XdgView *view);
    void onSubsurfaceChanged(QWaylandSurface *child, QWaylandSurface *parent);

private:
    void setupOutput(Output *output);
    void removeView(XdgView *view);

    QWaylandXdgShell  *m_xdgShell    = nullptr;
    LayerShellManager *m_layerShell  = nullptr;
    InputManager      *m_input       = nullptr;

    QList<XdgView*>   m_views;      // stacking order, front = bottom
    XdgView          *m_activeView  = nullptr;

    QList<Output*>    m_outputs;
};
