#pragma once
// compositor/output.h
// SPDX-License-Identifier: MIT

#include <QObject>
#include <QRect>
#include <QWaylandOutput>

class QScreen;
class QOpenGLWindow;
class AetherCompositor;

// ─────────────────────────────────────────────────────────────────────────────
// Output represents one physical display.  It owns the QWaylandOutput and
// the backing QWindow that the compositor renders into.
// ─────────────────────────────────────────────────────────────────────────────
class Output : public QObject
{
    Q_OBJECT
public:
    explicit Output(AetherCompositor *compositor, QScreen *screen);
    ~Output() override;

    QScreen          *screen()         const { return m_screen;      }
    QWaylandOutput   *waylandOutput()  const { return m_wlOutput;    }
    QRect             geometry()       const;

    // Usable area after subtracting reserved layer-shell zones
    QRect             availableGeometry() const { return m_available; }
    void              setAvailableGeometry(const QRect &r);

    void              scheduleRender();
    void              render();

signals:
    void availableGeometryChanged(const QRect &area);

private:
    AetherCompositor *m_compositor;
    QScreen          *m_screen;
    QWaylandOutput   *m_wlOutput;
    QRect             m_available;
};
