#pragma once
// shared/configmanager.h
// Thin INI-section/key reader with QFileSystemWatcher live-reload.
// Used by both compositor and shell.
// SPDX-License-Identifier: MIT

#include <QObject>
#include <QSettings>
#include <QFileSystemWatcher>
#include <QString>
#include <QVariant>
#include <QStringList>

class ConfigManager : public QObject
{
    Q_OBJECT
public:
    // Open (or create) the given config file.
    // Falls back to system-wide AETHER_SYSCONFDIR/<basename> if user file absent.
    explicit ConfigManager(const QString &filename, QObject *parent = nullptr);

    // Read a value; returns defaultValue if absent.
    QVariant value(const QString &section, const QString &key,
                   const QVariant &defaultValue = {}) const;

    QString  string (const QString &s, const QString &k, const QString  &def = {}) const;
    int      integer(const QString &s, const QString &k, int             def = 0 ) const;
    double   real   (const QString &s, const QString &k, double          def = 0.) const;
    bool     boolean(const QString &s, const QString &k, bool            def = false) const;

    // Write a value and flush immediately
    void setValue(const QString &section, const QString &key, const QVariant &value);

    QString filePath() const { return m_path; }

signals:
    void reloaded();

private slots:
    void onFileChanged(const QString &path);

private:
    void load();

    QString              m_path;
    QSettings           *m_settings = nullptr;
    QFileSystemWatcher   m_watcher;
};
