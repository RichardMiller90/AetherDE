// shared/keybindingmanager.cpp
// SPDX-License-Identifier: MIT

#include "keybindingmanager.h"
#include "configmanager.h"

#include <QFile>
#include <QTextStream>
#include <QStandardPaths>
#include <QLoggingCategory>

Q_LOGGING_CATEGORY(lcKeys, "aether.keybindings")

// ─────────────────────────────────────────────────────────────────────────────
KeybindingManager::KeybindingManager(ConfigManager *config, QObject *parent)
    : QObject(parent)
    , m_config(config)
{
    connect(config, &ConfigManager::reloaded, this, &KeybindingManager::reload);
    parse();
}

// ─────────────────────────────────────────────────────────────────────────────
void KeybindingManager::reload() { parse(); }

void KeybindingManager::parse()
{
    m_bindings.clear();

    // Look for keybindings.conf in XDG config dir
    const QString userDir = QStandardPaths::writableLocation(
                                QStandardPaths::GenericConfigLocation)
                          + "/aetherde/keybindings.conf";
    const QString sysPath = QString::fromUtf8(AETHER_SYSCONFDIR) + "/keybindings.conf";
    const QString path    = QFile::exists(userDir) ? userDir : sysPath;

    QFile f(path);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qCWarning(lcKeys) << "Cannot open keybindings file:" << path;
        return;
    }

    QTextStream in(&f);
    bool inCompositorSection = false;

    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (line.isEmpty() || line.startsWith('#')) continue;

        // Section header
        if (line.startsWith('[')) {
            inCompositorSection = (line.toLower() == "[compositor]");
            continue;
        }
        if (!inCompositorSection) continue;

        // key = action [args…]
        const int eq = line.indexOf('=');
        if (eq < 0) continue;

        const QString lhs  = line.left(eq).trimmed();
        const QString rhs  = line.mid(eq + 1).trimmed();

        // Parse modifiers + key from lhs, e.g. "Super+Shift+Return"
        QStringList parts = lhs.split('+', Qt::SkipEmptyParts);
        const QString keyStr = parts.takeLast();  // last token is the key

        Qt::KeyboardModifiers mods = parseMods(parts);
        Qt::Key               key  = parseKey(keyStr);

        if (key == Qt::Key_unknown) {
            qCDebug(lcKeys) << "Unknown key in binding:" << lhs;
            continue;
        }

        // Parse action + optional args from rhs
        QStringList rhsParts = rhs.split(QRegularExpression("\\s+"), Qt::SkipEmptyParts);
        if (rhsParts.isEmpty()) continue;
        const QString action = rhsParts.takeFirst();
        const QStringList args = rhsParts;

        Keybinding b;
        b.sequence = QKeySequence(key | (int)mods);
        b.action   = action;
        b.args     = args;
        m_bindings.append(b);

        qCDebug(lcKeys) << "Binding:" << lhs << "->" << action << args;
    }

    qCInfo(lcKeys) << "Loaded" << m_bindings.size() << "keybindings from" << path;
}

// ─────────────────────────────────────────────────────────────────────────────
bool KeybindingManager::handleKey(Qt::Key key, Qt::KeyboardModifiers mods)
{
    const QKeySequence pressed(key | (int)mods);
    for (const Keybinding &b : m_bindings) {
        if (b.sequence == pressed) {
            emit actionTriggered(b.action, b.args);
            return true;
        }
    }
    return false;
}

// ─────────────────────────────────────────────────────────────────────────────
Qt::KeyboardModifiers KeybindingManager::parseMods(const QStringList &tokens)
{
    Qt::KeyboardModifiers mods;
    for (const QString &t : tokens) {
        const QString lower = t.toLower();
        if      (lower == "super" || lower == "meta") mods |= Qt::MetaModifier;
        else if (lower == "ctrl"  || lower == "control") mods |= Qt::ControlModifier;
        else if (lower == "alt")                          mods |= Qt::AltModifier;
        else if (lower == "shift")                        mods |= Qt::ShiftModifier;
    }
    return mods;
}

Qt::Key KeybindingManager::parseKey(const QString &token)
{
    // Handle F1-F12
    static const QRegularExpression fkey("^[Ff](\\d+)$");
    auto m = fkey.match(token);
    if (m.hasMatch()) {
        int n = m.captured(1).toInt();
        if (n >= 1 && n <= 12)
            return static_cast<Qt::Key>(Qt::Key_F1 + n - 1);
    }

    // Common named keys
    static const QHash<QString, Qt::Key> named = {
        {"return",    Qt::Key_Return},
        {"enter",     Qt::Key_Return},
        {"space",     Qt::Key_Space},
        {"tab",       Qt::Key_Tab},
        {"escape",    Qt::Key_Escape},
        {"delete",    Qt::Key_Delete},
        {"backspace", Qt::Key_Backspace},
        {"home",      Qt::Key_Home},
        {"end",       Qt::Key_End},
        {"pageup",    Qt::Key_PageUp},
        {"pagedown",  Qt::Key_PageDown},
        {"left",      Qt::Key_Left},
        {"right",     Qt::Key_Right},
        {"up",        Qt::Key_Up},
        {"down",      Qt::Key_Down},
        {"print",     Qt::Key_Print},
        {"pause",     Qt::Key_Pause},
        {"insert",    Qt::Key_Insert},
        // XF86 media keys (mapped to Qt equivalents)
        {"xf86audioraisevolume",  Qt::Key_VolumeUp},
        {"xf86audiolowervolume",  Qt::Key_VolumeDown},
        {"xf86audiomute",         Qt::Key_VolumeMute},
        {"xf86audioplay",         Qt::Key_MediaPlay},
        {"xf86audionext",         Qt::Key_MediaNext},
        {"xf86audioprev",         Qt::Key_MediaPrevious},
        {"xf86monbrightnessup",   Qt::Key_MonBrightnessUp},
        {"xf86monbrightnessdown", Qt::Key_MonBrightnessDown},
    };

    const QString lower = token.toLower();
    if (named.contains(lower)) return named.value(lower);

    // Single ASCII letter or digit
    if (token.length() == 1) {
        const QChar c = token.toUpper().at(0);
        if (c.isLetterOrNumber())
            return static_cast<Qt::Key>(c.unicode());
    }

    return Qt::Key_unknown;
}
