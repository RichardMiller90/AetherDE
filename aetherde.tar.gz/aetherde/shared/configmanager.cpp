// shared/configmanager.cpp
// SPDX-License-Identifier: MIT

#include "configmanager.h"

#include <QDir>
#include <QStandardPaths>
#include <QFileInfo>
#include <QLoggingCategory>

Q_LOGGING_CATEGORY(lcConfig, "aether.config")

// ─────────────────────────────────────────────────────────────────────────────
ConfigManager::ConfigManager(const QString &filename, QObject *parent)
    : QObject(parent)
{
    // Determine user config path
    const QString userConfigDir = QStandardPaths::writableLocation(
                                      QStandardPaths::GenericConfigLocation)
                                + QStringLiteral("/aetherde");
    QDir().mkpath(userConfigDir);

    const QString userPath = userConfigDir + "/" + QFileInfo(filename).fileName();

    // If user file does not exist, copy from system default
    if (!QFile::exists(userPath)) {
        const QString sysPath = QString::fromUtf8(AETHER_SYSCONFDIR)
                              + "/" + QFileInfo(filename).fileName();
        if (QFile::exists(sysPath)) {
            QFile::copy(sysPath, userPath);
            qCDebug(lcConfig) << "Copied default config from" << sysPath;
        }
    }

    m_path = userPath;
    load();

    m_watcher.addPath(m_path);
    connect(&m_watcher, &QFileSystemWatcher::fileChanged,
            this, &ConfigManager::onFileChanged);
}

// ─────────────────────────────────────────────────────────────────────────────
void ConfigManager::load()
{
    delete m_settings;
    m_settings = new QSettings(m_path, QSettings::IniFormat, this);
    qCDebug(lcConfig) << "Loaded config:" << m_path;
}

void ConfigManager::onFileChanged(const QString &path)
{
    Q_UNUSED(path)
    // Re-add watch (some editors replace the file)
    m_watcher.addPath(m_path);
    load();
    emit reloaded();
    qCInfo(lcConfig) << "Config reloaded:" << m_path;
}

// ─────────────────────────────────────────────────────────────────────────────
QVariant ConfigManager::value(const QString &section, const QString &key,
                               const QVariant &defaultValue) const
{
    if (!m_settings) return defaultValue;
    m_settings->beginGroup(section);
    QVariant v = m_settings->value(key, defaultValue);
    m_settings->endGroup();
    return v;
}

QString ConfigManager::string(const QString &s, const QString &k,
                               const QString &def) const
{
    return value(s, k, def).toString();
}

int ConfigManager::integer(const QString &s, const QString &k, int def) const
{
    return value(s, k, def).toInt();
}

double ConfigManager::real(const QString &s, const QString &k, double def) const
{
    return value(s, k, def).toDouble();
}

bool ConfigManager::boolean(const QString &s, const QString &k, bool def) const
{
    const QVariant v = value(s, k, {});
    if (!v.isValid()) return def;
    const QString sv = v.toString().toLower();
    return (sv == "true" || sv == "1" || sv == "yes" || sv == "on");
}

// ─────────────────────────────────────────────────────────────────────────────
void ConfigManager::setValue(const QString &section, const QString &key,
                              const QVariant &val)
{
    if (!m_settings) return;
    m_settings->beginGroup(section);
    m_settings->setValue(key, val);
    m_settings->endGroup();
    m_settings->sync();
}
