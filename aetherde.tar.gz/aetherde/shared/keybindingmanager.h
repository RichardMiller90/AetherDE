#pragma once
// shared/keybindingmanager.h
// Parses keybindings.conf and emits actionTriggered() when a shortcut fires.
// The compositor connects actionTriggered() to its own action dispatch.
// SPDX-License-Identifier: MIT

#include <QObject>
#include <QHash>
#include <QKeySequence>
#include <QStringList>

class ConfigManager;

// ─────────────────────────────────────────────────────────────────────────────
struct Keybinding {
    QKeySequence sequence;
    QString      action;      // e.g. "exec"
    QStringList  args;        // e.g. {"foot"}
};

// ─────────────────────────────────────────────────────────────────────────────
class KeybindingManager : public QObject
{
    Q_OBJECT
public:
    explicit KeybindingManager(ConfigManager *config, QObject *parent = nullptr);

    const QList<Keybinding>& bindings() const { return m_bindings; }

    // Called by the compositor's input manager with every key press
    // Returns true if a binding was triggered.
    bool handleKey(Qt::Key key, Qt::KeyboardModifiers mods);

signals:
    void actionTriggered(const QString &action, const QStringList &args);

private slots:
    void reload();

private:
    void parse();
    static Qt::Key       parseKey(const QString &token);
    static Qt::KeyboardModifiers parseMods(const QStringList &tokens);

    ConfigManager       *m_config;
    QList<Keybinding>    m_bindings;
};
