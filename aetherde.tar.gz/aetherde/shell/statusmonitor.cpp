// shell/statusmonitor.cpp
// SPDX-License-Identifier: MIT

#include "statusmonitor.h"

#include <QDBusConnection>
#include <QDBusMessage>
#include <QDBusVariant>
#include <QDBusReply>
#include <QTimer>
#include <QLoggingCategory>
#include <cmath>

Q_LOGGING_CATEGORY(lcStatus, "aether.status")

// D-Bus service/path/interface constants
static const char NM_SERVICE[]       = "org.freedesktop.NetworkManager";
static const char NM_PATH[]          = "/org/freedesktop/NetworkManager";
static const char NM_IFACE[]         = "org.freedesktop.NetworkManager";
static const char UPOWER_SERVICE[]   = "org.freedesktop.UPower";
static const char UPOWER_PATH[]      = "/org/freedesktop/UPower";
static const char UPOWER_IFACE[]     = "org.freedesktop.UPower";
static const char PA_SERVICE[]       = "org.PulseAudio1";
static const char PA_PATH[]          = "/org/pulseaudio/core1";
static const char PA_IFACE[]         = "org.PulseAudio.Core1";

// ─────────────────────────────────────────────────────────────────────────────
StatusMonitor::StatusMonitor(QObject *parent)
    : QObject(parent)
{
    initNetworkManager();
    initUPower();
    initPulseAudio();

    // Periodic fallback poll every 30 s
    auto *poll = new QTimer(this);
    poll->setInterval(30'000);
    poll->setSingleShot(false);
    connect(poll, &QTimer::timeout, this, &StatusMonitor::pollAll);
    poll->start();

    pollAll();
}

// ─────────────────────────────────────────────────────────────────────────────
void StatusMonitor::initNetworkManager()
{
    auto &bus = QDBusConnection::systemBus();
    m_nmIface = new QDBusInterface(NM_SERVICE, NM_PATH, NM_IFACE, bus, this);
    if (!m_nmIface->isValid()) {
        qCWarning(lcStatus) << "NetworkManager D-Bus interface unavailable";
        return;
    }

    // Listen to StateChanged signal
    bus.connect(NM_SERVICE, NM_PATH, NM_IFACE, "StateChanged",
                this, SLOT(onNMStateChanged(uint)));
}

void StatusMonitor::initUPower()
{
    auto &bus = QDBusConnection::systemBus();
    m_upowerIface = new QDBusInterface(UPOWER_SERVICE, UPOWER_PATH, UPOWER_IFACE, bus, this);
    if (!m_upowerIface->isValid()) {
        qCWarning(lcStatus) << "UPower D-Bus interface unavailable";
        return;
    }

    // Find the first battery device
    QDBusReply<QList<QDBusObjectPath>> devices = m_upowerIface->call("EnumerateDevices");
    for (const QDBusObjectPath &path : devices.value()) {
        QDBusInterface dev(UPOWER_SERVICE, path.path(),
                           "org.freedesktop.UPower.Device", bus);
        const int type = dev.property("Type").toInt();
        if (type == 2) { // Battery
            m_batteryPath = path.path();
            m_hasBattery  = true;

            // Subscribe to PropertiesChanged
            bus.connect(UPOWER_SERVICE, m_batteryPath,
                        "org.freedesktop.DBus.Properties", "PropertiesChanged",
                        this, SLOT(onUPowerChanged(QString,QVariantMap,QStringList)));
            break;
        }
    }
}

void StatusMonitor::initPulseAudio()
{
    auto &bus = QDBusConnection::sessionBus();
    m_paIface = new QDBusInterface(PA_SERVICE, PA_PATH, PA_IFACE, bus, this);
    if (!m_paIface->isValid()) {
        qCDebug(lcStatus) << "PulseAudio/PipeWire D-Bus interface not found "
                             "(volume control limited)";
    }
}

// ─────────────────────────────────────────────────────────────────────────────
void StatusMonitor::pollAll()
{
    fetchNetworkState();
    fetchBatteryState();
    fetchVolumeState();
}

// ─────────────────────────────────────────────────────────────────────────────
void StatusMonitor::fetchNetworkState()
{
    if (!m_nmIface || !m_nmIface->isValid()) return;

    // NM state: 70 = connected global
    const uint state = m_nmIface->property("State").toUInt();
    const bool avail = (state >= 60);

    bool wifiConnected = false;
    QString ssid;

    if (avail) {
        // Walk active connections to find Wi-Fi
        QDBusReply<QList<QDBusObjectPath>> acs =
            m_nmIface->call("GetAllDevices");
        for (const QDBusObjectPath &devPath : acs.value()) {
            QDBusInterface dev(NM_SERVICE, devPath.path(),
                               "org.freedesktop.NetworkManager.Device",
                               QDBusConnection::systemBus());
            const int devType = dev.property("DeviceType").toInt();
            if (devType == 2) { // NM_DEVICE_TYPE_WIFI
                const uint devState = dev.property("State").toUInt();
                if (devState == 100) { // NM_DEVICE_STATE_ACTIVATED
                    wifiConnected = true;
                    const QString apPath =
                        dev.property("ActiveAccessPoint").value<QDBusObjectPath>().path();
                    if (!apPath.isEmpty() && apPath != "/") {
                        QDBusInterface ap(NM_SERVICE, apPath,
                                          "org.freedesktop.NetworkManager.AccessPoint",
                                          QDBusConnection::systemBus());
                        ssid = QString::fromUtf8(ap.property("Ssid").toByteArray());
                    }
                    break;
                }
            }
        }
        if (!wifiConnected) {
            // Ethernet – get connection name
            QDBusInterface nmConn(NM_SERVICE, NM_PATH,
                                  "org.freedesktop.NetworkManager",
                                  QDBusConnection::systemBus());
            const QList<QDBusObjectPath> activeConns =
                nmConn.property("ActiveConnections")
                      .value<QList<QDBusObjectPath>>();
            if (!activeConns.isEmpty()) {
                QDBusInterface conn(NM_SERVICE, activeConns.first().path(),
                    "org.freedesktop.NetworkManager.Connection.Active",
                    QDBusConnection::systemBus());
                ssid = conn.property("Id").toString();
            }
        }
    }

    if (m_netAvailable != avail || m_netWifi != wifiConnected || m_netName != ssid) {
        m_netAvailable = avail;
        m_netWifi      = wifiConnected;
        m_netName      = ssid;
        emit networkChanged();
    }
}

// ─────────────────────────────────────────────────────────────────────────────
void StatusMonitor::fetchBatteryState()
{
    if (!m_hasBattery || m_batteryPath.isEmpty()) return;
    QDBusInterface dev(UPOWER_SERVICE, m_batteryPath,
                       "org.freedesktop.UPower.Device",
                       QDBusConnection::systemBus());
    const int  pct     = qBound(0, qRound(dev.property("Percentage").toDouble()), 100);
    const uint state   = dev.property("State").toUInt();
    const bool charging = (state == 1 || state == 5); // charging or pending-charge

    if (m_batteryPercent != pct || m_batteryCharging != charging) {
        m_batteryPercent  = pct;
        m_batteryCharging = charging;
        emit batteryChanged();
    }
}

// ─────────────────────────────────────────────────────────────────────────────
void StatusMonitor::fetchVolumeState()
{
    if (!m_paIface || !m_paIface->isValid()) return;

    const QDBusObjectPath sinkPath =
        m_paIface->property("FallbackSink").value<QDBusObjectPath>();
    if (sinkPath.path().isEmpty()) return;

    QDBusInterface sink(PA_SERVICE, sinkPath.path(),
                        "org.PulseAudio.Core1.Device",
                        QDBusConnection::sessionBus());

    const QList<uint> volumes = sink.property("Volume").value<QList<uint>>();
    const bool muted          = sink.property("Mute").toBool();

    int pct = 0;
    if (!volumes.isEmpty()) {
        const uint avg = std::accumulate(volumes.begin(), volumes.end(), 0u) / volumes.size();
        pct = qBound(0, qRound(avg * 100.0 / 65536.0), 150);
    }

    if (m_volume != pct || m_muted != muted) {
        m_volume = pct;
        m_muted  = muted;
        emit volumeChanged();
    }
}

// ─────────────────────────────────────────────────────────────────────────────
void StatusMonitor::adjustVolume(int delta)
{
    if (!m_paIface || !m_paIface->isValid()) return;
    const QDBusObjectPath sinkPath =
        m_paIface->property("FallbackSink").value<QDBusObjectPath>();
    if (sinkPath.path().isEmpty()) return;

    QDBusInterface sink(PA_SERVICE, sinkPath.path(),
                        "org.PulseAudio.Core1.Device",
                        QDBusConnection::sessionBus());
    QList<uint> volumes = sink.property("Volume").value<QList<uint>>();
    for (uint &v : volumes) {
        int newV = static_cast<int>(v) + delta * 655;
        v = static_cast<uint>(qBound(0, newV, 98304)); // cap at 150%
    }
    sink.setProperty("Volume", QVariant::fromValue(volumes));
    fetchVolumeState();
}

void StatusMonitor::toggleMute()
{
    if (!m_paIface || !m_paIface->isValid()) return;
    const QDBusObjectPath sinkPath =
        m_paIface->property("FallbackSink").value<QDBusObjectPath>();
    if (sinkPath.path().isEmpty()) return;

    QDBusInterface sink(PA_SERVICE, sinkPath.path(),
                        "org.PulseAudio.Core1.Device",
                        QDBusConnection::sessionBus());
    sink.setProperty("Mute", !m_muted);
    fetchVolumeState();
}

// ─────────────────────────────────────────────────────────────────────────────
void StatusMonitor::onNMStateChanged(uint /*state*/)
{
    fetchNetworkState();
}

void StatusMonitor::onUPowerChanged(const QString &, const QVariantMap &, const QStringList &)
{
    fetchBatteryState();
}
