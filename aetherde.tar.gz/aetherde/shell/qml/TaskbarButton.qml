// shell/qml/TaskbarButton.qml
// SPDX-License-Identifier: MIT
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: btn
    implicitWidth:  Math.min(180, titleLabel.implicitWidth + 48)
    implicitHeight: 30
    radius:         6
    color:          active    ? "#44aaaaff"
                  : hov.hovered ? "#22ffffff"
                  : "#1a1a3a"
    border { color: active ? "#6666cc" : "transparent"; width: 1 }

    required property string title
    required property string appId
    required property bool   active
    required property bool   minimized

    signal clicked()
    signal closeRequested()

    Behavior on color { ColorAnimation { duration: 80 } }

    RowLayout {
        anchors { fill: parent; leftMargin: 8; rightMargin: 6 }
        spacing: 6

        // App icon via XDG theme
        Image {
            source: appId !== "" ? ("image://theme/" + appId) : ""
            width: 18; height: 18
            fillMode: Image.PreserveAspectFit
            visible: status === Image.Ready
            Layout.alignment: Qt.AlignVCenter
        }

        Text {
            id: titleLabel
            text:  title || appId || "Window"
            color: active ? "#ffffff" : minimized ? "#888899" : "#c0c0e0"
            font { pixelSize: 12; weight: active ? Font.Medium : Font.Normal }
            elide: Text.ElideRight
            Layout.fillWidth: true
            Layout.alignment: Qt.AlignVCenter
        }

        // Close button – only on hover
        Text {
            text:    "×"
            color:   "#88ffffff"
            font.pixelSize: 14
            visible: hov.hovered
            Layout.alignment: Qt.AlignVCenter
            TapHandler {
                onTapped: btn.closeRequested()
            }
        }
    }

    // Active underline indicator
    Rectangle {
        visible: active
        anchors { bottom: parent.bottom; left: parent.left; right: parent.right; bottomMargin: 2 }
        height: 2
        radius: 1
        color:  "#6666ff"
    }

    HoverHandler { id: hov }
    TapHandler   { onTapped: btn.clicked() }

    ToolTip {
        visible: hov.hovered && title !== ""
        text:    title
        delay:   600
    }
}
