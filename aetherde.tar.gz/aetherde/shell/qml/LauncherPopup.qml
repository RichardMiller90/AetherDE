// shell/qml/LauncherPopup.qml
// Full-width application launcher with live search
// SPDX-License-Identifier: MIT

import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import AetherShell 1.0

LayerWindow {
    id: launcher
    layer:   LayerWindow.Top
    anchors: LayerWindow.AnchorLeft | LayerWindow.AnchorTop
    width:   480
    height:  560
    visible: false
    keyboardInteractivity: LayerWindow.OnDemand

    function toggle() {
        visible = !visible
        if (visible) {
            searchBox.text = ""
            desktopModel.filter = ""
            searchBox.forceActiveFocus()
        }
    }

    // ── Background ─────────────────────────────────────────────────────────────
    Rectangle {
        anchors.fill: parent
        color:  "#e81a1a2e"
        radius: 10
        border { color: "#44aaaaff"; width: 1 }

        layer.enabled: true
        layer.effect: MultiEffect {
            shadowEnabled:         true
            shadowColor:           "#aa000000"
            shadowBlur:            0.9
            shadowVerticalOffset:  8
        }

        ColumnLayout {
            anchors { fill: parent; margins: 12 }
            spacing: 10

            // ── Search box ───────────────────────────────────────────────────
            TextField {
                id: searchBox
                Layout.fillWidth: true
                placeholderText:  "Search apps…"
                font.pixelSize:   15
                leftPadding:      36
                color:            "#e0e0ff"
                background: Rectangle {
                    color:  "#33ffffff"
                    radius: 8
                    border { color: searchBox.activeFocus ? "#6666ff" : "#33ffffff"; width: 1 }
                }

                // Search icon
                Image {
                    anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter }
                    source: "qrc:/icons/search.svg"
                    width: 16; height: 16
                    opacity: 0.6
                }

                Keys.onEscapePressed: launcher.visible = false
                Keys.onReturnPressed: {
                    if (appGrid.currentItem)
                        appGrid.currentItem.launchApp()
                }
                Keys.onDownPressed: appGrid.forceActiveFocus()

                onTextChanged: desktopModel.filter = text
            }

            // ── App grid ─────────────────────────────────────────────────────
            GridView {
                id: appGrid
                Layout.fillWidth:  true
                Layout.fillHeight: true
                clip:              true
                cellWidth:         104
                cellHeight:        100
                model:             desktopModel
                currentIndex:      0

                Keys.onReturnPressed:  currentItem && currentItem.launchApp()
                Keys.onEscapePressed:  { launcher.visible = false; searchBox.forceActiveFocus() }

                delegate: AppDelegate {
                    width:    appGrid.cellWidth  - 8
                    height:   appGrid.cellHeight - 8

                    appName:     model.name
                    iconName:    model.iconName
                    isSelected:  GridView.isCurrentItem

                    onClicked: launchApp()

                    function launchApp() {
                        desktopModel.launch(model.appId)
                        launcher.visible = false
                    }
                }

                ScrollBar.vertical: ScrollBar {}
            }

            // ── Footer: power actions ─────────────────────────────────────────
            RowLayout {
                Layout.fillWidth: true
                spacing: 6

                Item { Layout.fillWidth: true }

                PanelButton {
                    text: "⏻  Shut down"
                    onClicked: sessionManager.requestShutdown()
                }
                PanelButton {
                    text: "↺  Restart"
                    onClicked: sessionManager.requestReboot()
                }
                PanelButton {
                    text: "🔒  Lock"
                    onClicked: sessionManager.requestLockScreen()
                }
                PanelButton {
                    text: "⎋  Log out"
                    onClicked: sessionManager.requestLogout()
                }
            }
        }
    }

    // Close when focus leaves
    onActiveFocusChanged: if (!activeFocus) visible = false
}
