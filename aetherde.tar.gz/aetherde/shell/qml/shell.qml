// shell/qml/shell.qml
// AetherDE Shell – Root QML document
// SPDX-License-Identifier: MIT

import QtQuick
import QtQuick.Window
import QtQuick.Controls
import QtQuick.Layouts
import AetherShell 1.0

Item {
    id: shellRoot

    // ── Panel (top bar) ────────────────────────────────────────────────────────
    Panel {
        id: panel
    }

    // ── Application Launcher ───────────────────────────────────────────────────
    Launcher {
        id: launcher
        visible: false
    }

    // ── Notification Overlay ───────────────────────────────────────────────────
    NotificationOverlay {
        id: notifOverlay
    }

    // ── Wallpaper ──────────────────────────────────────────────────────────────
    WallpaperView {
        id: wallpaperView
    }

    // ── Keyboard shortcut: Super → launcher ───────────────────────────────────
    Shortcut {
        sequences: ["Meta", "Meta+Space"]
        onActivated: launcher.toggle()
    }

    // Connect notification signals
    Connections {
        target: notifManager
        function onNewNotification(id) { notifOverlay.show(id) }
    }
}
