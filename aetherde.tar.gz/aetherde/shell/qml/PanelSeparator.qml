// shell/qml/PanelSeparator.qml
import QtQuick
Rectangle {
    implicitWidth:  1
    implicitHeight: 22
    color: "#33ffffff"
    opacity: 0.6
}
