// shell/qml/AppDelegate.qml
// SPDX-License-Identifier: MIT
import QtQuick
import QtQuick.Controls

Rectangle {
    id: tile
    radius: 10
    color:  isSelected ? "#44aaaaff" : hov.hovered ? "#22ffffff" : "transparent"

    required property string appName
    required property string iconName
    required property bool   isSelected

    signal clicked()

    Behavior on color { ColorAnimation { duration: 100 } }

    Column {
        anchors.centerIn: parent
        spacing: 6

        // App icon: try XDG theme first, then fallback SVG
        Image {
            id: iconImg
            anchors.horizontalCenter: parent.horizontalCenter
            width: 48; height: 48
            source: iconName !== ""
                  ? ("image://theme/" + iconName)
                  : (dataDir + "/icons/default-app.svg")
            fillMode: Image.PreserveAspectFit
            smooth:   true

            onStatusChanged: {
                if (status === Image.Error)
                    source = dataDir + "/icons/default-app.svg"
            }
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text:    appName
            color:   "#e0e0ff"
            font.pixelSize: 11
            horizontalAlignment: Text.AlignHCenter
            width:   tile.width - 8
            elide:   Text.ElideRight
            wrapMode: Text.WordWrap
            maximumLineCount: 2
        }
    }

    HoverHandler  { id: hov }
    TapHandler    { onTapped: tile.clicked() }

    // Selection glow
    Rectangle {
        visible:      tile.isSelected
        anchors.fill: parent
        radius:       parent.radius
        color:        "transparent"
        border { color: "#6666ff"; width: 2 }
    }
}
