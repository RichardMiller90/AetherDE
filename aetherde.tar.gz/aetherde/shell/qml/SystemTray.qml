// shell/qml/SystemTray.qml
// StatusNotifierItem icon row
// SPDX-License-Identifier: MIT

import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Row {
    id: trayRow
    spacing: 2
    height:  30

    Repeater {
        model: trayManager.items

        delegate: Rectangle {
            width: 28; height: 28
            radius: 6
            color: hov.hovered ? "#22ffffff" : "transparent"
            Behavior on color { ColorAnimation { duration: 80 } }

            Image {
                anchors.centerIn: parent
                width: 20; height: 20
                source: modelData.iconName !== ""
                      ? ("image://theme/" + modelData.iconName)
                      : ""
                fillMode: Image.PreserveAspectFit
                smooth:   true
            }

            HoverHandler { id: hov }

            TapHandler {
                acceptedButtons: Qt.LeftButton
                onTapped: trayManager.activate(modelData.service,
                              mapToGlobal(0, 0).x,
                              mapToGlobal(0, 0).y)
            }
            TapHandler {
                acceptedButtons: Qt.RightButton
                onTapped: trayManager.secondaryActivate(modelData.service,
                              mapToGlobal(0, 0).x,
                              mapToGlobal(0, 0).y)
            }

            WheelHandler {
                onWheel: (event) => {
                    trayManager.scroll(modelData.service,
                        event.angleDelta.y > 0 ? 1 : -1,
                        "vertical")
                }
            }

            ToolTip {
                visible: hov.hovered
                text:    modelData.tooltipTitle || modelData.title || modelData.id
                delay:   500
            }
        }
    }
}
