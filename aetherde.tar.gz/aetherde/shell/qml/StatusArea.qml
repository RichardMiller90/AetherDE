// shell/qml/StatusArea.qml
// Battery · Network · Volume quick-status row.
// Reads from the C++ StatusMonitor (NM / UPower / PulseAudio via D-Bus).
// SPDX-License-Identifier: MIT

import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Row {
    id: statusArea
    spacing: 4
    height:  30

    // ── Volume ─────────────────────────────────────────────────────────────────
    StatusIcon {
        iconName: statusMonitor.volumeMuted           ? "audio-volume-muted"
                : statusMonitor.volumePercent > 66   ? "audio-volume-high"
                : statusMonitor.volumePercent > 33   ? "audio-volume-medium"
                :                                      "audio-volume-low"
        tooltip: statusMonitor.volumeMuted
               ? "Muted"
               : (statusMonitor.volumePercent + "%")

        WheelHandler {
            onWheel: (ev) => statusMonitor.adjustVolume(ev.angleDelta.y > 0 ? 5 : -5)
        }
        TapHandler { onTapped: statusMonitor.toggleMute() }
    }

    // ── Network ────────────────────────────────────────────────────────────────
    StatusIcon {
        visible:  true
        iconName: statusMonitor.networkAvailable
                ? (statusMonitor.networkWifi ? "network-wireless" : "network-wired")
                : "network-offline"
        tooltip:  statusMonitor.networkAvailable
                ? (statusMonitor.networkName || "Connected")
                : "Offline"
    }

    // ── Battery (hide if no battery present) ───────────────────────────────────
    StatusIcon {
        visible:  statusMonitor.hasBattery
        iconName: statusMonitor.batteryCharging
                ? "battery-caution-charging"
                : statusMonitor.batteryPercent > 90 ? "battery-full"
                : statusMonitor.batteryPercent > 60 ? "battery-good"
                : statusMonitor.batteryPercent > 30 ? "battery-low"
                :                                     "battery-caution"
        tooltip: statusMonitor.batteryPercent + "%"
               + (statusMonitor.batteryCharging ? " (charging)" : "")
    }
}
