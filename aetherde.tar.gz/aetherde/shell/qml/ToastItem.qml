// shell/qml/ToastItem.qml
// SPDX-License-Identifier: MIT
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: toast
    width:  336
    height: layout.implicitHeight + 20
    radius: 12
    color:  "#ee1a1a3e"
    border { color: "#44aaaaff"; width: 1 }
    clip:   false

    required property int    notifId
    required property string appName
    required property string summary
    required property string body
    required property string iconSrc

    signal dismissed()
    signal actionClicked(string key)

    // Auto-dismiss after 5 s
    Timer {
        interval: 5000
        running:  true
        onTriggered: dismissAnim.start()
    }

    // ── Slide-in / out animation ───────────────────────────────────────────────
    property real slideX: 0
    transform: Translate { x: toast.slideX }

    NumberAnimation on opacity {
        id: dismissAnim
        to: 0; duration: 220
        onFinished: toast.dismissed()
    }

    NumberAnimation {
        id: slideInAnim
        target: toast; property: "slideX"
        from: 360; to: 0; duration: 260
        easing.type: Easing.OutCubic
        running: true
    }

    layer.enabled: true
    layer.effect: MultiEffect {
        shadowEnabled:        true
        shadowColor:          "#88000000"
        shadowBlur:           0.7
        shadowVerticalOffset: 4
    }

    // ── Content ────────────────────────────────────────────────────────────────
    RowLayout {
        id: layout
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 12 }
        spacing: 10

        // App icon
        Image {
            source: iconSrc !== "" ? ("image://theme/" + iconSrc)
                                   : (dataDir + "/icons/notification.svg")
            width:  36; height: 36
            fillMode: Image.PreserveAspectFit
            Layout.alignment: Qt.AlignTop
            onStatusChanged: if (status === Image.Error) source = dataDir + "/icons/notification.svg"
        }

        Column {
            Layout.fillWidth: true
            spacing: 3

            Text {
                text:  appName || "Notification"
                color: "#aaaacc"
                font { pixelSize: 11; weight: Font.Medium }
                elide: Text.ElideRight
                width: parent.width
            }
            Text {
                text:  summary
                color: "#e0e0ff"
                font { pixelSize: 13; weight: Font.Bold }
                elide: Text.ElideRight
                width: parent.width
            }
            Text {
                visible: body !== ""
                text:    body
                color:   "#c0c0e0"
                font.pixelSize: 12
                wrapMode: Text.WordWrap
                width:    parent.width
                maximumLineCount: 3
                elide:    Text.ElideRight
            }
        }

        // Dismiss ×
        Text {
            text: "×"
            color: "#88ffffff"
            font.pixelSize: 18
            Layout.alignment: Qt.AlignTop
            TapHandler { onTapped: dismissAnim.start() }
            HoverHandler { cursorShape: Qt.PointingHandCursor }
        }
    }

    // Click whole toast to dismiss
    TapHandler { onTapped: dismissAnim.start() }
}
