// shell/qml/NotificationCenter.qml
// Right-side slide-in notification history panel
// SPDX-License-Identifier: MIT

import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import AetherShell 1.0

LayerWindow {
    id: center
    layer:   LayerWindow.Top
    anchors: LayerWindow.AnchorRight | LayerWindow.AnchorTop | LayerWindow.AnchorBottom
    width:   380
    visible: false
    keyboardInteractivity: LayerWindow.OnDemand

    function toggle() { visible = !visible }

    // Slide animation
    property real slideOffset: visible ? 0 : width
    Behavior on slideOffset { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
    transform: Translate { x: center.slideOffset }

    // ── Background ─────────────────────────────────────────────────────────────
    Rectangle {
        anchors.fill: parent
        color:  "#f01a1a2e"
        border { color: "#33aaaaff"; width: 1 }

        ColumnLayout {
            anchors { fill: parent; margins: 12 }
            spacing: 8

            // Header
            RowLayout {
                Layout.fillWidth: true

                Text {
                    text: "Notifications"
                    color: "#e0e0ff"
                    font { pixelSize: 16; weight: Font.Bold }
                    Layout.fillWidth: true
                }

                Button {
                    text: "Clear all"
                    flat: true
                    enabled: notifManager.notifications.length > 0
                    onClicked: notifManager.dismissAll()
                    contentItem: Text {
                        text: parent.text
                        color: "#aaaaff"
                        font.pixelSize: 12
                    }
                    background: Rectangle { color: "transparent" }
                }
            }

            Rectangle { height: 1; color: "#33ffffff"; Layout.fillWidth: true }

            // Empty state
            Text {
                visible: notifManager.notifications.length === 0
                text: "No notifications"
                color: "#666688"
                font.pixelSize: 14
                Layout.alignment: Qt.AlignHCenter
                Layout.topMargin: 40
            }

            // Notification list
            ScrollView {
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true

                Column {
                    width: parent.width
                    spacing: 6

                    Repeater {
                        model: notifManager.notifications

                        delegate: NotificationCard {
                            width: parent.width
                            notif: modelData
                            onDismissClicked: notifManager.CloseNotification(modelData.id)
                            onActionClicked: (key) =>
                                notifManager.invokeAction(modelData.id, key)
                        }
                    }
                }
            }
        }
    }

    // Close on outside click via a transparent overlay behind the panel
    // (handled by the compositor's input routing)
}
