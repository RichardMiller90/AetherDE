// shell/qml/Panel.qml
// AetherDE top panel: launcher button · taskbar · clock · system tray · status
// SPDX-License-Identifier: MIT

import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Window
import AetherShell 1.0

LayerWindow {
    id: panel
    layer:         LayerWindow.Top
    anchors:       LayerWindow.AnchorLeft | LayerWindow.AnchorRight | LayerWindow.AnchorTop
    exclusiveZone: panelHeight
    height:        panelHeight

    readonly property int panelHeight: 40

    // ── Background ─────────────────────────────────────────────────────────────
    Rectangle {
        anchors.fill: parent
        color: "#cc0f0f23"   // semi-transparent dark navy

        // Subtle bottom separator line
        Rectangle {
            anchors { bottom: parent.bottom; left: parent.left; right: parent.right }
            height: 1
            color: "#33ffffff"
        }
    }

    // ── Main layout ────────────────────────────────────────────────────────────
    RowLayout {
        anchors { fill: parent; leftMargin: 8; rightMargin: 8 }
        spacing: 4

        // ── App launcher button ──────────────────────────────────────────────
        PanelButton {
            id: launcherBtn
            icon.name: "aetherde"
            icon.source: dataDir + "/icons/aether-logo.svg"
            checkable: true
            checked: launcherPopup.visible
            onClicked: launcherPopup.toggle()
            ToolTip.text: "Application Launcher  (⊞)"
            ToolTip.visible: hovered
        }

        // ── Separator ────────────────────────────────────────────────────────
        PanelSeparator {}

        // ── Pinned/running app taskbar ───────────────────────────────────────
        Taskbar {
            id: taskbar
            Layout.fillWidth: true
        }

        // ── Spacer ───────────────────────────────────────────────────────────
        Item { Layout.fillWidth: true }

        // ── System tray ──────────────────────────────────────────────────────
        SystemTray { id: sysTray }

        PanelSeparator {}

        // ── Status indicators ─────────────────────────────────────────────────
        StatusArea { id: statusArea }

        PanelSeparator {}

        // ── Clock ────────────────────────────────────────────────────────────
        Clock { id: clock }

        // ── Notification count badge ──────────────────────────────────────────
        NotificationBadge {
            count: notifManager.notifications.length
            onClicked: notifCenter.toggle()
        }
    }

    // ── Launcher popup (layer overlay) ────────────────────────────────────────
    Loader {
        id: launcherPopup
        source: "LauncherPopup.qml"
        active: true

        function toggle() { item && item.toggle() }
    }

    // ── Notification center (right slide-in) ──────────────────────────────────
    Loader {
        id: notifCenter
        source: "NotificationCenter.qml"
        active: true

        function toggle() { item && item.toggle() }
    }
}
