// shell/qml/NotificationCard.qml
// SPDX-License-Identifier: MIT
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: card
    radius: 10
    color:  hov.hovered ? "#33aaaaff" : "#22ffffff"
    height: layout.implicitHeight + 16
    Behavior on color { ColorAnimation { duration: 80 } }

    required property var notif   // Notification struct from C++
    signal dismissClicked()
    signal actionClicked(string key)

    ColumnLayout {
        id: layout
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 10 }
        spacing: 6

        // Header row
        RowLayout {
            Layout.fillWidth: true
            spacing: 8

            Image {
                source: notif.appIcon !== ""
                      ? ("image://theme/" + notif.appIcon) : ""
                visible: notif.appIcon !== ""
                width: 20; height: 20
                fillMode: Image.PreserveAspectFit
            }

            Text {
                text:  notif.appName
                color: "#aaaacc"
                font { pixelSize: 11; weight: Font.Medium }
                Layout.fillWidth: true
            }

            Text {
                text: "×"
                color: hov.hovered ? "#ccccff" : "#666688"
                font.pixelSize: 16
                TapHandler { onTapped: card.dismissClicked() }
                HoverHandler { cursorShape: Qt.PointingHandCursor }
            }
        }

        Text {
            text:  notif.summary
            color: "#e0e0ff"
            font { pixelSize: 13; weight: Font.Bold }
            wrapMode: Text.WordWrap
            Layout.fillWidth: true
        }

        Text {
            visible: notif.body !== ""
            text:    notif.body
            color:   "#c0c0e0"
            font.pixelSize: 12
            wrapMode: Text.WordWrap
            Layout.fillWidth: true
            maximumLineCount: 5
            elide: Text.ElideRight
        }

        // Action buttons
        Row {
            visible: notif.actions && notif.actions.length > 0
            spacing: 6
            Layout.topMargin: 2

            Repeater {
                // actions = ["key1","Label1","key2","Label2",…]
                model: Math.floor((notif.actions ? notif.actions.length : 0) / 2)
                delegate: Button {
                    text: notif.actions[index * 2 + 1]
                    flat: false
                    onClicked: card.actionClicked(notif.actions[index * 2])
                    contentItem: Text {
                        text: parent.text
                        color: "#aaaaff"
                        font.pixelSize: 11
                        horizontalAlignment: Text.AlignHCenter
                    }
                    background: Rectangle {
                        color:  parent.hovered ? "#44aaaaff" : "#22aaaaff"
                        radius: 6
                        border { color: "#44aaaaff"; width: 1 }
                    }
                }
            }
        }
    }

    HoverHandler { id: hov }
}
