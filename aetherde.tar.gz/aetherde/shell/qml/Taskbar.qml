// shell/qml/Taskbar.qml
// Running-window taskbar backed by the C++ ForeignToplevelModel which
// subscribes to ext-foreign-toplevel-list-v1 from the compositor.
// SPDX-License-Identifier: MIT

import QtQuick
import QtQuick.Controls

Item {
    id: taskbar
    implicitHeight: 30
    clip: true

    ScrollView {
        anchors.fill: parent
        contentWidth: taskRow.implicitWidth
        ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
        ScrollBar.vertical.policy:   ScrollBar.AlwaysOff

        Row {
            id: taskRow
            spacing: 4
            height:  taskbar.height

            Repeater {
                // toplevelModel is a ForeignToplevelModel* set as a QML context property
                model: toplevelModel

                delegate: TaskButton {
                    height:    taskbar.height
                    wid:       index          // use row index as window id
                    title:     model.title
                    iconName:  model.appId    // fall back to appId for icon lookup
                    isActive:  model.active
                    minimized: model.minimized

                    onActivate:  {
                        if (model.handle) {
                            if (model.minimized) model.handle.unminimize()
                            model.handle.activate()
                        }
                    }
                    onMinimize: {
                        if (model.handle) {
                            model.minimized ? model.handle.unminimize()
                                            : model.handle.minimize()
                        }
                    }
                    onClose: { if (model.handle) model.handle.close() }
                }
            }
        }
    }
}
