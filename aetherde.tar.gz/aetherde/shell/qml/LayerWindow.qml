// shell/qml/LayerWindow.qml
// QML-facing wrapper for C++ ShellWindow (wlr-layer-shell-v1 client surface).
// Exposes the same Layer / Anchor / exclusiveZone API as ShellWindow.
// SPDX-License-Identifier: MIT

import QtQuick
import QtQuick.Window
import AetherShell 1.0

// ShellQuickWindow is a QQuickWindow subclass registered from C++ as
//   qmlRegisterType<ShellQuickWindow>("AetherShell", 1, 0, "LayerWindow")
// It inherits ShellWindow's properties and calls applyLayerShell() on expose.
ShellQuickWindow {
    id: lw

    // ── Layer constants (mirror ShellWindow::Layer) ────────────────────────────
    readonly property int Background: 0
    readonly property int Bottom:     1
    readonly property int Top:        2
    readonly property int Overlay:    3

    // ── Anchor bit-flags (mirror ShellWindow::Anchor) ─────────────────────────
    readonly property int AnchorNone:   0
    readonly property int AnchorTop:    1
    readonly property int AnchorBottom: 2
    readonly property int AnchorLeft:   4
    readonly property int AnchorRight:  8
    readonly property int AnchorFill:   15

    // ── Keyboard interactivity ─────────────────────────────────────────────────
    readonly property int KbNone:     0
    readonly property int KbExclusive:1
    readonly property int OnDemand:   2

    // ── Defaults ──────────────────────────────────────────────────────────────
    flags: Qt.FramelessWindowHint
    color: "transparent"
}
