// shell/qml/NotificationOverlay.qml
// Animated toast notification popups (top-right)
// SPDX-License-Identifier: MIT

import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import AetherShell 1.0

LayerWindow {
    id: overlay
    layer:   LayerWindow.Overlay
    anchors: LayerWindow.AnchorRight | LayerWindow.AnchorTop
    width:   360
    height:  Screen.desktopAvailableHeight
    // Input passthrough – only capture events inside actual toast items
    interactiveRegion: toastColumn

    function show(id) {
        // Find the notification in the model and push a toast
        const list = notifManager.notifications
        for (let i = 0; i < list.length; ++i) {
            if (list[i].id === id) {
                toastModel.insert(0, {
                    notifId: id,
                    appName: list[i].appName,
                    summary: list[i].summary,
                    body:    list[i].body,
                    icon:    list[i].appIcon
                })
                return
            }
        }
    }

    // Toast list model
    ListModel { id: toastModel }

    // Container
    Column {
        id: toastColumn
        anchors { top: parent.top; right: parent.right; margins: 12 }
        spacing: 8

        Repeater {
            model: toastModel
            delegate: ToastItem {
                notifId: model.notifId
                appName: model.appName
                summary: model.summary
                body:    model.body
                iconSrc: model.icon

                onDismissed: toastModel.remove(index)
                onActionClicked: (key) => {
                    notifManager.invokeAction(model.notifId, key)
                    toastModel.remove(index)
                }
            }
        }
    }
}
