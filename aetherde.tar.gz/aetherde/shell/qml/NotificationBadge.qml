// shell/qml/NotificationBadge.qml
// Bell icon with unread count
// SPDX-License-Identifier: MIT
import QtQuick
import QtQuick.Controls

Rectangle {
    id: badge
    implicitWidth:  28
    implicitHeight: 28
    radius:         6
    color:          hov.hovered ? "#22ffffff" : "transparent"
    Behavior on color { ColorAnimation { duration: 80 } }

    required property int count
    signal clicked()

    Image {
        anchors.centerIn: parent
        width: 18; height: 18
        source: count > 0 ? "image://theme/notification-new"
                          : "image://theme/notification"
        fillMode: Image.PreserveAspectFit
    }

    // Red count bubble
    Rectangle {
        visible: badge.count > 0
        anchors { top: parent.top; right: parent.right; topMargin: 2; rightMargin: 2 }
        width:  Math.max(14, countText.implicitWidth + 6)
        height: 14
        radius: 7
        color:  "#e74c3c"

        Text {
            id: countText
            anchors.centerIn: parent
            text:  badge.count > 99 ? "99+" : badge.count.toString()
            color: "white"
            font { pixelSize: 9; weight: Font.Bold }
        }
    }

    HoverHandler { id: hov }
    TapHandler   { onTapped: badge.clicked() }
    ToolTip {
        visible: hov.hovered
        text:    badge.count > 0 ? badge.count + " notification(s)" : "No notifications"
        delay: 500
    }
}
