// shell/qml/Clock.qml
// SPDX-License-Identifier: MIT
import QtQuick
import QtQuick.Controls

Item {
    id: clock
    implicitWidth:  timeText.implicitWidth + 16
    implicitHeight: 30

    Timer {
        interval: 1000
        repeat:   true
        running:  true
        triggeredOnStart: true
        onTriggered: {
            const now  = new Date()
            timeText.text = Qt.formatTime(now, "hh:mm")
            dateText.text = Qt.formatDate(now, "dddd, MMMM d")
        }
    }

    Column {
        anchors.centerIn: parent
        spacing: -2

        Text {
            id: timeText
            color: "#e0e0ff"
            font { pixelSize: 14; weight: Font.Medium }
            horizontalAlignment: Text.AlignHCenter
            anchors.horizontalCenter: parent.horizontalCenter
        }
    }

    ToolTip {
        visible: mouseArea.containsMouse
        text:    dateText.text
        delay:   400
    }

    Text { id: dateText; visible: false }

    MouseArea {
        id: mouseArea
        anchors.fill: parent
        hoverEnabled: true
    }
}
