// shell/qml/WallpaperView.qml
// SPDX-License-Identifier: MIT

import QtQuick
import AetherShell 1.0

LayerWindow {
    id: wallView
    layer:   LayerWindow.Background
    anchors: LayerWindow.AnchorFill
    width:   Screen.desktopAvailableWidth
    height:  Screen.desktopAvailableHeight

    // Solid colour fallback (used until image loads)
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            orientation: Gradient.Vertical
            GradientStop { position: 0.0; color: "#0f0f1a" }
            GradientStop { position: 1.0; color: "#1a1a3a" }
        }
    }

    // Wallpaper image
    Image {
        id: wpImage
        anchors.fill: parent
        source:       wallpaperMgr.currentPath !== ""
                    ? ("file://" + wallpaperMgr.currentPath) : ""
        fillMode:     fillModeFromString(wallpaperMgr.fillMode)
        smooth:       true
        asynchronous: true
        visible:      status === Image.Ready

        function fillModeFromString(s) {
            switch (s) {
            case "Stretch":               return Image.Stretch
            case "PreserveAspectFit":     return Image.PreserveAspectFit
            case "PreserveAspectCrop":    return Image.PreserveAspectCrop
            case "Tile":                  return Image.Tile
            case "TileVertically":        return Image.TileVertically
            case "TileHorizontally":      return Image.TileHorizontally
            default:                      return Image.PreserveAspectCrop
            }
        }

        // Crossfade on wallpaper change
        Behavior on source {
            SequentialAnimation {
                NumberAnimation { target: wpImage; property: "opacity"; to: 0; duration: 300 }
                PropertyAction  {}
                NumberAnimation { target: wpImage; property: "opacity"; to: 1; duration: 300 }
            }
        }
    }

    // Very subtle darkening vignette so panel text reads cleanly
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            orientation: Gradient.Vertical
            GradientStop { position: 0.0; color: "#44000000" }
            GradientStop { position: 0.12; color: "transparent" }
            GradientStop { position: 1.0; color: "transparent" }
        }
    }
}
