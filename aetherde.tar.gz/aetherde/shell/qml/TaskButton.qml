// shell/qml/TaskButton.qml
// SPDX-License-Identifier: MIT
import QtQuick
import QtQuick.Controls

Rectangle {
    id: btn
    implicitWidth:  Math.min(180, titleText.implicitWidth + iconImg.width + 24)
    height:         30
    radius:         6
    color: isActive   ? "#44aaaaff"
         : hov.hovered? "#22ffffff"
         : "transparent"

    required property int    wid
    required property string title
    required property string iconName
    required property bool   isActive
    required property bool   minimized

    signal activate()
    signal minimize()
    signal close()

    opacity: minimized ? 0.5 : 1.0
    Behavior on color   { ColorAnimation { duration: 80 } }
    Behavior on opacity { NumberAnimation { duration: 120 } }

    // Active indicator bar
    Rectangle {
        visible: isActive
        anchors { bottom: parent.bottom; horizontalCenter: parent.horizontalCenter }
        width: parent.width * 0.6; height: 2; radius: 1
        color: "#8888ff"
    }

    Row {
        anchors { verticalCenter: parent.verticalCenter; left: parent.left; leftMargin: 6 }
        spacing: 5

        Image {
            id: iconImg
            source: iconName !== "" ? ("image://theme/" + iconName) : ""
            visible: iconName !== ""
            width: 18; height: 18
            fillMode: Image.PreserveAspectFit
            anchors.verticalCenter: parent.verticalCenter
        }
        Text {
            id: titleText
            text:  btn.title
            color: "#e0e0ff"
            font.pixelSize: 12
            elide: Text.ElideRight
            width: btn.width - iconImg.width - 24
            anchors.verticalCenter: parent.verticalCenter
        }
    }

    HoverHandler { id: hov }

    TapHandler {
        acceptedButtons: Qt.LeftButton
        onTapped: isActive ? btn.minimize() : btn.activate()
    }

    TapHandler {
        acceptedButtons: Qt.MiddleButton
        onTapped: btn.close()
    }

    // Right-click context menu
    TapHandler {
        acceptedButtons: Qt.RightButton
        onTapped: ctxMenu.popup()
    }

    Menu {
        id: ctxMenu
        MenuItem { text: "Restore";    onTriggered: btn.activate()  }
        MenuItem { text: "Minimise";   onTriggered: btn.minimize()  }
        MenuSeparator {}
        MenuItem { text: "Close";      onTriggered: btn.close()     }
    }
}
