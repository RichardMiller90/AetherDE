// shell/qml/StatusIcon.qml
// SPDX-License-Identifier: MIT
import QtQuick
import QtQuick.Controls

Rectangle {
    id: si
    implicitWidth:  28
    implicitHeight: 28
    radius:         6
    color:          hov.hovered ? "#22ffffff" : "transparent"
    Behavior on color { ColorAnimation { duration: 80 } }

    required property string iconName
    property  string tooltipText: ""

    Image {
        anchors.centerIn: parent
        width: 18; height: 18
        source:   si.iconName !== "" ? ("image://theme/" + si.iconName) : ""
        fillMode: Image.PreserveAspectFit
        smooth:   true
    }

    HoverHandler { id: hov }

    ToolTip {
        visible: hov.hovered && si.tooltipText !== ""
        text:    si.tooltipText
        delay:   500
    }
}
