// shell/qml/PanelButton.qml
// SPDX-License-Identifier: MIT
import QtQuick
import QtQuick.Controls

AbstractButton {
    id: btn
    implicitWidth:  Math.max(32, contentItem.implicitWidth + 16)
    implicitHeight: 30

    background: Rectangle {
        radius: 6
        color:  btn.pressed   ? "#44ffffff"
              : btn.hovered   ? "#22ffffff"
              : btn.checked   ? "#33aaaaff"
              : "transparent"
        Behavior on color { ColorAnimation { duration: 80 } }
    }

    contentItem: Row {
        spacing: 4
        leftPadding: 4; rightPadding: 4
        Image {
            visible: btn.icon.source.toString() !== "" || btn.icon.name !== ""
            source:  btn.icon.source
            width: 20; height: 20
            fillMode: Image.PreserveAspectFit
            anchors.verticalCenter: parent.verticalCenter
        }
        Text {
            visible: btn.text !== ""
            text:    btn.text
            color:   "#e0e0ff"
            font.pixelSize: 13
            anchors.verticalCenter: parent.verticalCenter
        }
    }
}
