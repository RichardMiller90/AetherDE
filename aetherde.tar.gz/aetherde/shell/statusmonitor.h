#pragma once
// shell/statusmonitor.h
// Polls/subscribes to system status via D-Bus:
//   - NetworkManager  → network state, SSID
//   - UPower          → battery level, charging state
//   - PulseAudio/PW   → volume via org.PulseAudio.Core1 or wireplumber
// SPDX-License-Identifier: MIT

#include <QObject>
#include <QString>
#include <QDBusInterface>
#include <QDBusServiceWatcher>

class StatusMonitor : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int     volumePercent   READ volumePercent   NOTIFY volumeChanged)
    Q_PROPERTY(bool    volumeMuted     READ volumeMuted     NOTIFY volumeChanged)
    Q_PROPERTY(bool    networkAvailable READ networkAvailable NOTIFY networkChanged)
    Q_PROPERTY(bool    networkWifi     READ networkWifi     NOTIFY networkChanged)
    Q_PROPERTY(QString networkName     READ networkName     NOTIFY networkChanged)
    Q_PROPERTY(bool    hasBattery      READ hasBattery      NOTIFY batteryChanged)
    Q_PROPERTY(int     batteryPercent  READ batteryPercent  NOTIFY batteryChanged)
    Q_PROPERTY(bool    batteryCharging READ batteryCharging NOTIFY batteryChanged)

public:
    explicit StatusMonitor(QObject *parent = nullptr);

    int     volumePercent()    const { return m_volume;           }
    bool    volumeMuted()      const { return m_muted;            }
    bool    networkAvailable() const { return m_netAvailable;     }
    bool    networkWifi()      const { return m_netWifi;          }
    QString networkName()      const { return m_netName;          }
    bool    hasBattery()       const { return m_hasBattery;       }
    int     batteryPercent()   const { return m_batteryPercent;   }
    bool    batteryCharging()  const { return m_batteryCharging;  }

    Q_INVOKABLE void adjustVolume(int delta);
    Q_INVOKABLE void toggleMute();

signals:
    void volumeChanged();
    void networkChanged();
    void batteryChanged();

private slots:
    void pollAll();
    void onNMStateChanged(uint state);
    void onUPowerChanged(const QString &interface,
                         const QVariantMap &changed,
                         const QStringList &invalidated);

private:
    void initNetworkManager();
    void initUPower();
    void initPulseAudio();
    void fetchNetworkState();
    void fetchBatteryState();
    void fetchVolumeState();

    // Volume
    int  m_volume          = 50;
    bool m_muted           = false;

    // Network
    bool    m_netAvailable = false;
    bool    m_netWifi      = false;
    QString m_netName;

    // Battery
    bool m_hasBattery      = false;
    int  m_batteryPercent  = 0;
    bool m_batteryCharging = false;

    // D-Bus interfaces (lazily constructed)
    QDBusInterface *m_nmIface      = nullptr;
    QDBusInterface *m_upowerIface  = nullptr;
    QDBusInterface *m_paIface      = nullptr;
    QString         m_batteryPath;
};
