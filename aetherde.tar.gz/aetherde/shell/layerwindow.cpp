// shell/layerwindow.cpp
// SPDX-License-Identifier: MIT

#include "layerwindow.h"

LayerWindow::LayerWindow(QWindow *parent)
    : QQuickWindow(parent)
    , m_shellWindow(ShellWindow::Layer::Top,
                    ShellWindow::Anchors(ShellWindow::AnchorNone))
{
    // Frameless, transparent background
    setFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint);
    setColor(Qt::transparent);
}

// ── Forwarding accessors ──────────────────────────────────────────────────────

ShellWindow::Layer   LayerWindow::layer()   const { return m_shellWindow.layer(); }
ShellWindow::Anchors LayerWindow::anchors() const { return m_shellWindow.anchors(); }
int  LayerWindow::exclusiveZone()           const { return m_shellWindow.exclusiveZone(); }
int  LayerWindow::marginTop()               const { return m_shellWindow.marginTop(); }
int  LayerWindow::marginBottom()            const { return m_shellWindow.marginBottom(); }
int  LayerWindow::marginLeft()              const { return m_shellWindow.marginLeft(); }
int  LayerWindow::marginRight()             const { return m_shellWindow.marginRight(); }
ShellWindow::KbInteract LayerWindow::keyboardInteractivity() const { return m_shellWindow.keyboardInteractivity(); }

// ── Setters ───────────────────────────────────────────────────────────────────

void LayerWindow::setLayer(ShellWindow::Layer l)
{
    if (m_shellWindow.layer() == l) return;
    // Layer can only be set before the surface is committed.
    // Re-create the helper window if necessary.
    emit layerChanged();
}

void LayerWindow::setAnchors(ShellWindow::Anchors a)
{
    m_shellWindow.setAnchors(a);
    emit anchorsChanged();
}

void LayerWindow::setExclusiveZone(int z)
{
    m_shellWindow.setExclusiveZone(z);
    emit exclusiveZoneChanged();
}

void LayerWindow::setMarginTop(int v)    { m_shellWindow.setMarginTop(v);    emit marginsChanged(); }
void LayerWindow::setMarginBottom(int v) { m_shellWindow.setMarginBottom(v); emit marginsChanged(); }
void LayerWindow::setMarginLeft(int v)   { m_shellWindow.setMarginLeft(v);   emit marginsChanged(); }
void LayerWindow::setMarginRight(int v)  { m_shellWindow.setMarginRight(v);  emit marginsChanged(); }

void LayerWindow::setKeyboardInteractivity(ShellWindow::KbInteract mode)
{
    m_shellWindow.setKeyboardInteractivity(mode);
    emit keyboardInteractivityChanged();
}
