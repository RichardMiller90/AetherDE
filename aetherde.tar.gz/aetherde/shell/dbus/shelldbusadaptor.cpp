// shell/dbus/shelldbusadaptor.cpp
// SPDX-License-Identifier: MIT

#include "shelldbusadaptor.h"
#include "../desktopmodel.h"
#include "../notificationmanager.h"

#include <QDBusConnection>
#include <QLoggingCategory>

Q_LOGGING_CATEGORY(lcDBus, "aether.dbus")

// ─────────────────────────────────────────────────────────────────────────────
ShellDBusAdaptor::ShellDBusAdaptor(DesktopModel        *desktopModel,
                                    NotificationManager *notifMgr,
                                    QObject             *parent)
    : QDBusAbstractAdaptor(parent ? parent : desktopModel)
    , m_desktopModel(desktopModel)
    , m_notifMgr(notifMgr)
{
    setAutoRelaySignals(true);
}

// ─────────────────────────────────────────────────────────────────────────────
void ShellDBusAdaptor::ActivateWindow(uint wid)
{
    qCDebug(lcDBus) << "ActivateWindow" << wid;
    // Signal is relayed to compositor via org.AetherDE.Compositor D-Bus call.
    // The compositor's own D-Bus adaptor (not shown here for brevity) handles
    // the stacking/focus change.
    QDBusConnection::sessionBus().call(
        QDBusMessage::createMethodCall(
            "org.AetherDE.Compositor", "/org/AetherDE/Compositor",
            "org.AetherDE.Compositor", "ActivateWindow")
        << QVariant::fromValue(wid));
}

void ShellDBusAdaptor::MinimizeWindow(uint wid)
{
    qCDebug(lcDBus) << "MinimizeWindow" << wid;
    QDBusConnection::sessionBus().call(
        QDBusMessage::createMethodCall(
            "org.AetherDE.Compositor", "/org/AetherDE/Compositor",
            "org.AetherDE.Compositor", "MinimizeWindow")
        << QVariant::fromValue(wid));
}

void ShellDBusAdaptor::CloseWindow(uint wid)
{
    qCDebug(lcDBus) << "CloseWindow" << wid;
    QDBusConnection::sessionBus().call(
        QDBusMessage::createMethodCall(
            "org.AetherDE.Compositor", "/org/AetherDE/Compositor",
            "org.AetherDE.Compositor", "CloseWindow")
        << QVariant::fromValue(wid));
}

QVariantList ShellDBusAdaptor::GetWindowList() const
{
    // Returns a list fetched from the compositor over D-Bus.
    QDBusMessage reply = QDBusConnection::sessionBus().call(
        QDBusMessage::createMethodCall(
            "org.AetherDE.Compositor", "/org/AetherDE/Compositor",
            "org.AetherDE.Compositor", "GetWindowList"));
    if (reply.type() == QDBusMessage::ReplyMessage)
        return reply.arguments().value(0).toList();
    return {};
}

void ShellDBusAdaptor::LaunchApp(const QString &appId)
{
    qCDebug(lcDBus) << "LaunchApp" << appId;
    m_desktopModel->launch(appId);
}

void ShellDBusAdaptor::ToggleLauncher()
{
    // Emit a signal that the QML root (shell.qml) connects to
    QMetaObject::invokeMethod(parent(), "toggleLauncher", Qt::QueuedConnection);
}

void ShellDBusAdaptor::ShowDesktop()
{
    QMetaObject::invokeMethod(parent(), "showDesktop", Qt::QueuedConnection);
}
