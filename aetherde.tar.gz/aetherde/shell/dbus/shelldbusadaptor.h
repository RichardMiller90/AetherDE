#pragma once
// shell/dbus/shelldbusadaptor.h
// Exposes org.AetherDE.Shell over D-Bus so the compositor (and external
// tools) can query and control the shell.
// SPDX-License-Identifier: MIT

#include <QObject>
#include <QVariantList>
#include <QVariantMap>
#include <QDBusAbstractAdaptor>

class DesktopModel;
class NotificationManager;

class ShellDBusAdaptor : public QDBusAbstractAdaptor
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.AetherDE.Shell")
    Q_CLASSINFO("D-Bus Introspection",
        "<interface name=\"org.AetherDE.Shell\">"
        "  <method name=\"ActivateWindow\"><arg direction=\"in\" type=\"u\" name=\"wid\"/></method>"
        "  <method name=\"MinimizeWindow\"><arg direction=\"in\" type=\"u\" name=\"wid\"/></method>"
        "  <method name=\"CloseWindow\"><arg direction=\"in\" type=\"u\" name=\"wid\"/></method>"
        "  <method name=\"GetWindowList\"><arg direction=\"out\" type=\"aa{sv}\" name=\"windows\"/></method>"
        "  <method name=\"LaunchApp\"><arg direction=\"in\" type=\"s\" name=\"appId\"/></method>"
        "  <method name=\"ToggleLauncher\"/>"
        "  <method name=\"ShowDesktop\"/>"
        "  <signal name=\"WindowAdded\"><arg type=\"u\" name=\"wid\"/></signal>"
        "  <signal name=\"WindowRemoved\"><arg type=\"u\" name=\"wid\"/></signal>"
        "  <signal name=\"ActiveWindowChanged\"><arg type=\"u\" name=\"wid\"/></signal>"
        "</interface>")

public:
    explicit ShellDBusAdaptor(DesktopModel *desktopModel,
                               NotificationManager *notifMgr,
                               QObject *parent = nullptr);

public slots:
    void         ActivateWindow(uint wid);
    void         MinimizeWindow(uint wid);
    void         CloseWindow(uint wid);
    QVariantList GetWindowList() const;
    void         LaunchApp(const QString &appId);
    void         ToggleLauncher();
    void         ShowDesktop();

signals:
    void WindowAdded(uint wid);
    void WindowRemoved(uint wid);
    void ActiveWindowChanged(uint wid);

private:
    DesktopModel        *m_desktopModel;
    NotificationManager *m_notifMgr;
};
