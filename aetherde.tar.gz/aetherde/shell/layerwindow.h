#pragma once
// shell/layerwindow.h
// QML-exposed item that wraps ShellWindow (wlr-layer-shell surface).
// Allows QML to declare:
//
//   LayerWindow {
//       layer:   LayerWindow.Top
//       anchors: LayerWindow.AnchorLeft | LayerWindow.AnchorRight | LayerWindow.AnchorTop
//       exclusiveZone: 40
//       height:  40
//       …
//   }
//
// SPDX-License-Identifier: MIT

#include "shellwindow.h"
#include <QQuickWindow>
#include <QtQml/qqmlregistration.h>

class LayerWindow : public QQuickWindow
{
    Q_OBJECT
    QML_ELEMENT
    QML_NAMED_ELEMENT(LayerWindow)

    Q_PROPERTY(ShellWindow::Layer   layer    READ layer    WRITE setLayer    NOTIFY layerChanged)
    Q_PROPERTY(ShellWindow::Anchors anchors  READ anchors  WRITE setAnchors  NOTIFY anchorsChanged)
    Q_PROPERTY(int  exclusiveZone   READ exclusiveZone  WRITE setExclusiveZone  NOTIFY exclusiveZoneChanged)
    Q_PROPERTY(int  marginTop       READ marginTop      WRITE setMarginTop      NOTIFY marginsChanged)
    Q_PROPERTY(int  marginBottom    READ marginBottom   WRITE setMarginBottom   NOTIFY marginsChanged)
    Q_PROPERTY(int  marginLeft      READ marginLeft     WRITE setMarginLeft     NOTIFY marginsChanged)
    Q_PROPERTY(int  marginRight     READ marginRight    WRITE setMarginRight    NOTIFY marginsChanged)
    Q_PROPERTY(ShellWindow::KbInteract keyboardInteractivity
               READ keyboardInteractivity
               WRITE setKeyboardInteractivity
               NOTIFY keyboardInteractivityChanged)

public:
    // Re-export enums so QML can use LayerWindow.Top, LayerWindow.AnchorLeft etc.
    enum LayerEnum {
        Background = int(ShellWindow::Layer::Background),
        Bottom     = int(ShellWindow::Layer::Bottom),
        Top        = int(ShellWindow::Layer::Top),
        Overlay    = int(ShellWindow::Layer::Overlay),
    };
    Q_ENUM(LayerEnum)

    enum AnchorFlag : uint32_t {
        AnchorNone   = 0,
        AnchorTop    = 1,
        AnchorBottom = 2,
        AnchorLeft   = 4,
        AnchorRight  = 8,
        AnchorFill   = 15,
    };
    Q_DECLARE_FLAGS(AnchorFlags, AnchorFlag)
    Q_FLAG(AnchorFlags)

    enum KbInteractEnum {
        None      = int(ShellWindow::KbInteract::None),
        Exclusive = int(ShellWindow::KbInteract::Exclusive),
        OnDemand  = int(ShellWindow::KbInteract::OnDemand),
    };
    Q_ENUM(KbInteractEnum)

    explicit LayerWindow(QWindow *parent = nullptr);

    ShellWindow::Layer    layer()   const;
    ShellWindow::Anchors  anchors() const;
    int  exclusiveZone()            const;
    int  marginTop()                const;
    int  marginBottom()             const;
    int  marginLeft()               const;
    int  marginRight()              const;
    ShellWindow::KbInteract keyboardInteractivity() const;

    void setLayer(ShellWindow::Layer layer);
    void setAnchors(ShellWindow::Anchors anchors);
    void setExclusiveZone(int z);
    void setMarginTop(int v);
    void setMarginBottom(int v);
    void setMarginLeft(int v);
    void setMarginRight(int v);
    void setKeyboardInteractivity(ShellWindow::KbInteract mode);

signals:
    void layerChanged();
    void anchorsChanged();
    void exclusiveZoneChanged();
    void marginsChanged();
    void keyboardInteractivityChanged();

private:
    ShellWindow m_shellWindow;
};

Q_DECLARE_OPERATORS_FOR_FLAGS(LayerWindow::AnchorFlags)
