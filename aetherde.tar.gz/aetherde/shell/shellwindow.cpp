// shell/shellwindow.cpp
// SPDX-License-Identifier: MIT

#include "shellwindow.h"

#include <QGuiApplication>
#include <QScreen>
#include <QPlatformNativeInterface>
#include <QLoggingCategory>

// We use Qt's native interface to reach the underlying wl_surface and then
// send zwlr_layer_shell_v1 requests directly through the generated client
// stubs produced by wayland-scanner.
extern "C" {
#include <wayland-client.h>
// generated stubs (produced by wayland_generate_protocol in CMake)
#include "wlr-layer-shell-unstable-v1-client.h"
}

Q_LOGGING_CATEGORY(lcShellWin, "aether.shellwindow")

// ── Integration helper (one per display) ──────────────────────────────────────
class LayerShellIntegration
{
public:
    static LayerShellIntegration *instance()
    {
        static LayerShellIntegration s_inst;
        return &s_inst;
    }

    zwlr_layer_shell_v1 *shell() const { return m_shell; }

    bool isValid() const { return m_shell != nullptr; }

private:
    LayerShellIntegration()
    {
        // Retrieve the wl_display from Qt's platform native interface
        auto *ni = QGuiApplication::platformNativeInterface();
        if (!ni) return;
        auto *display = static_cast<wl_display *>(
            ni->nativeResourceForIntegration("wl_display"));
        if (!display) return;

        // Roundtrip to enumerate globals
        auto *registry = wl_display_get_registry(display);
        static const wl_registry_listener s_listener = {
            [](void *data, wl_registry *reg, uint32_t name,
               const char *iface, uint32_t version) {
                auto *self = static_cast<LayerShellIntegration*>(data);
                if (std::string_view(iface) == zwlr_layer_shell_v1_interface.name) {
                    self->m_shell = static_cast<zwlr_layer_shell_v1*>(
                        wl_registry_bind(reg, name,
                                         &zwlr_layer_shell_v1_interface,
                                         std::min(version, 4u)));
                }
            },
            [](void *, wl_registry *, uint32_t) {}  // global_remove
        };
        wl_registry_add_listener(registry, &s_listener, this);
        wl_display_roundtrip(display);
        wl_registry_destroy(registry);

        if (!m_shell)
            qCWarning(lcShellWin) << "zwlr_layer_shell_v1 not available "
                                     "(compositor does not support it)";
    }

    zwlr_layer_shell_v1 *m_shell = nullptr;
};

// ─────────────────────────────────────────────────────────────────────────────
ShellWindow::ShellWindow(Layer layer, Anchors anchors, QWindow *parent)
    : QWindow(parent)
    , m_layer(layer)
    , m_anchors(anchors)
    , m_lsIntegration(LayerShellIntegration::instance())
{
    setFlag(Qt::FramelessWindowHint, true);
    setFlag(Qt::WindowStaysOnTopHint, true);
}

ShellWindow::~ShellWindow() = default;

// ─────────────────────────────────────────────────────────────────────────────
void ShellWindow::exposeEvent(QExposeEvent *ev)
{
    QWindow::exposeEvent(ev);
    if (!m_layerApplied && isExposed())
        applyLayerShell();
}

void ShellWindow::resizeEvent(QResizeEvent *ev)
{
    QWindow::resizeEvent(ev);
}

// ─────────────────────────────────────────────────────────────────────────────
void ShellWindow::applyLayerShell()
{
    if (!m_lsIntegration || !m_lsIntegration->isValid()) {
        qCWarning(lcShellWin) << "Layer shell unavailable; "
                                 "falling back to normal window";
        return;
    }

    auto *ni = QGuiApplication::platformNativeInterface();
    auto *wlSurface = static_cast<wl_surface *>(
        ni->nativeResourceForWindow("surface", this));
    if (!wlSurface) {
        qCWarning(lcShellWin) << "Could not obtain wl_surface from window";
        return;
    }

    auto *wlOutput = static_cast<wl_output *>(
        ni->nativeResourceForScreen("output", screen() ? screen() : QGuiApplication::primaryScreen()));

    auto *ls = zwlr_layer_shell_v1_get_layer_surface(
        m_lsIntegration->shell(),
        wlSurface,
        wlOutput,
        static_cast<uint32_t>(m_layer),
        "aetherde-shell");

    if (!ls) {
        qCWarning(lcShellWin) << "Failed to create layer surface";
        return;
    }

    // Configure anchors, exclusive zone, margins
    zwlr_layer_surface_v1_set_anchor(ls, static_cast<uint32_t>(m_anchors));
    zwlr_layer_surface_v1_set_exclusive_zone(ls, m_exclusiveZone);
    zwlr_layer_surface_v1_set_margin(ls, m_marginTop, m_marginRight,
                                         m_marginBottom, m_marginLeft);

    // Desired size (0 = fill from anchor)
    const int w = (m_anchors & AnchorLeft) && (m_anchors & AnchorRight) ? 0 : width();
    const int h = (m_anchors & AnchorTop)  && (m_anchors & AnchorBottom)? 0 : height();
    zwlr_layer_surface_v1_set_size(ls, static_cast<uint32_t>(w),
                                       static_cast<uint32_t>(h));

    // Configure callback
    static const zwlr_layer_surface_v1_listener s_lsListener = {
        // configure
        [](void *data, zwlr_layer_surface_v1 *lsSurface,
           uint32_t serial, uint32_t /*w*/, uint32_t /*h*/) {
            zwlr_layer_surface_v1_ack_configure(lsSurface, serial);
            auto *self = static_cast<wl_surface*>(data);
            wl_surface_commit(self);
        },
        // closed
        [](void * /*data*/, zwlr_layer_surface_v1 *lsSurface) {
            zwlr_layer_surface_v1_destroy(lsSurface);
        }
    };
    zwlr_layer_surface_v1_add_listener(ls, &s_lsListener, wlSurface);

    wl_surface_commit(wlSurface);
    m_layerApplied = true;

    qCDebug(lcShellWin) << "Layer shell applied: layer=" << (int)m_layer
                        << "anchors=" << (int)m_anchors
                        << "excl=" << m_exclusiveZone;
}

// ─────────────────────────────────────────────────────────────────────────────
void ShellWindow::setExclusiveZone(int z) { m_exclusiveZone = z; }
void ShellWindow::setMarginTop   (int v) { m_marginTop     = v; }
void ShellWindow::setMarginBottom(int v) { m_marginBottom  = v; }
void ShellWindow::setMarginLeft  (int v) { m_marginLeft    = v; }
void ShellWindow::setMarginRight (int v) { m_marginRight   = v; }
void ShellWindow::setKeyboardInteractivity(KbInteract mode) { m_kbMode = mode; }
