#pragma once
// shell/shellquickwindow.h
// QQuickWindow that also acts as a wlr-layer-shell client surface.
// Registered into QML as LayerWindow via qmlRegisterType.
// SPDX-License-Identifier: MIT

#include "shellwindow.h"
#include <QQuickWindow>

// We cannot multiply-inherit QQuickWindow and ShellWindow (both ultimately
// from QObject).  Instead ShellQuickWindow IS a QQuickWindow and OWNS a
// ShellWindow for the layer-shell protocol work; it mirrors all relevant
// properties and delegates applyLayerShell() calls.

class ShellQuickWindow : public QQuickWindow
{
    Q_OBJECT
    Q_PROPERTY(int     layer                READ layer    WRITE setLayer)
    Q_PROPERTY(int     anchors              READ anchors  WRITE setAnchors)
    Q_PROPERTY(int     exclusiveZone        READ exclusiveZone  WRITE setExclusiveZone)
    Q_PROPERTY(int     marginTop            READ marginTop      WRITE setMarginTop)
    Q_PROPERTY(int     marginBottom         READ marginBottom   WRITE setMarginBottom)
    Q_PROPERTY(int     marginLeft           READ marginLeft     WRITE setMarginLeft)
    Q_PROPERTY(int     marginRight          READ marginRight    WRITE setMarginRight)
    Q_PROPERTY(int     keyboardInteractivity READ kbInteract    WRITE setKbInteract)

public:
    explicit ShellQuickWindow(QWindow *parent = nullptr);
    ~ShellQuickWindow() override;

    int  layer()          const { return (int)m_layer;   }
    int  anchors()        const { return (int)m_anchors; }
    int  exclusiveZone()  const { return m_exclZone;     }
    int  marginTop()      const { return m_mTop;         }
    int  marginBottom()   const { return m_mBottom;      }
    int  marginLeft()     const { return m_mLeft;        }
    int  marginRight()    const { return m_mRight;       }
    int  kbInteract()     const { return (int)m_kbMode;  }

    void setLayer(int l);
    void setAnchors(int a);
    void setExclusiveZone(int z);
    void setMarginTop(int v);
    void setMarginBottom(int v);
    void setMarginLeft(int v);
    void setMarginRight(int v);
    void setKbInteract(int m);

    // Called by QML to register this type
    static void registerQmlType();

protected:
    void exposeEvent(QExposeEvent *ev) override;

private:
    void applyLayerShell();
    bool m_applied = false;

    ShellWindow::Layer   m_layer   = ShellWindow::Layer::Top;
    ShellWindow::Anchors m_anchors = ShellWindow::AnchorNone;
    int  m_exclZone = 0;
    int  m_mTop = 0, m_mBottom = 0, m_mLeft = 0, m_mRight = 0;
    ShellWindow::KbInteract m_kbMode = ShellWindow::KbInteract::None;

    // Delegate the actual protocol work to ShellWindow
    ShellWindow *m_helper = nullptr;
};
