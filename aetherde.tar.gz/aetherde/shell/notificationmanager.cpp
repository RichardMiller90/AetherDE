// shell/notificationmanager.cpp
// SPDX-License-Identifier: MIT

#include "notificationmanager.h"

#include <QDBusConnection>
#include <QLoggingCategory>

Q_LOGGING_CATEGORY(lcNotif, "aether.notifications")

static constexpr int  DEFAULT_TIMEOUT_MS  = 5000;
static constexpr int  CRITICAL_TIMEOUT_MS = 0;     // never auto-close
static constexpr uint REASON_EXPIRED      = 1;
static constexpr uint REASON_USER         = 2;
static constexpr uint REASON_PROG         = 3;
static constexpr uint REASON_UNDEF        = 4;

// ─────────────────────────────────────────────────────────────────────────────
NotificationManager::NotificationManager(QObject *parent)
    : QObject(parent)
{
    QDBusConnection bus = QDBusConnection::sessionBus();
    if (!bus.registerObject("/org/freedesktop/Notifications", this,
            QDBusConnection::ExportAllSlots | QDBusConnection::ExportAllSignals))
        qCWarning(lcNotif) << "Failed to register notification object on D-Bus";

    if (!bus.registerService("org.freedesktop.Notifications"))
        qCWarning(lcNotif) << "Failed to claim org.freedesktop.Notifications "
                              "(another notification daemon may be running)";

    qCInfo(lcNotif) << "Notification daemon ready";
}

NotificationManager::~NotificationManager() = default;

// ─────────────────────────────────────────────────────────────────────────────
QStringList NotificationManager::GetCapabilities()
{
    return {
        "actions",
        "body",
        "body-hyperlinks",
        "body-markup",
        "icon-static",
        "persistence",
        "sound",
    };
}

void NotificationManager::GetServerInformation(QString &name, QString &vendor,
                                                QString &version, QString &spec_version)
{
    name         = QStringLiteral("AetherDE Notification Daemon");
    vendor       = QStringLiteral("AetherDE");
    version      = AETHER_VERSION;
    spec_version = QStringLiteral("1.2");
}

// ─────────────────────────────────────────────────────────────────────────────
uint NotificationManager::Notify(const QString     &app_name,
                                  uint               replaces_id,
                                  const QString     &app_icon,
                                  const QString     &summary,
                                  const QString     &body,
                                  const QStringList &actions,
                                  const QVariantMap &hints,
                                  int                expire_timeout)
{
    // Determine ID
    uint id = (replaces_id > 0 && findById(replaces_id)) ? replaces_id : m_nextId++;

    // Build Notification struct
    Notification n;
    n.id        = id;
    n.appName   = app_name;
    n.appIcon   = app_icon;
    n.summary   = summary;
    n.body      = body;
    n.actions   = actions;
    n.hints     = hints;
    n.timeout   = expire_timeout;
    n.resident  = hints.value("resident",  false).toBool();
    n.transient = hints.value("transient", false).toBool();

    // Urgency
    if (hints.contains("urgency"))
        n.urgency = hints.value("urgency").toInt();

    // Sound
    if (hints.contains("sound-file"))
        n.soundFile = hints.value("sound-file").toString();

    // Replace or append
    bool replaced = false;
    for (int i = 0; i < m_notifications.size(); ++i) {
        if (m_notifications[i].id == id) {
            m_notifications[i] = n;
            replaced = true;
            break;
        }
    }
    if (!replaced)
        m_notifications.prepend(n);   // newest first

    // Cancel existing timer for this id
    if (auto *t = m_timers.take(id)) {
        t->stop();
        t->deleteLater();
    }

    // Determine expiry
    int ms = expire_timeout;
    if (ms < 0)        ms = (n.urgency == 2) ? CRITICAL_TIMEOUT_MS : DEFAULT_TIMEOUT_MS;
    if (ms > 0) {
        auto *timer = new QTimer(this);
        timer->setSingleShot(true);
        connect(timer, &QTimer::timeout, this, [this, id]() { expireNotification(id); });
        timer->start(ms);
        m_timers.insert(id, timer);
    }

    emit notificationsChanged();
    emit newNotification(id);

    qCDebug(lcNotif) << "Notify id=" << id << "from" << app_name << ":" << summary;
    return id;
}

// ─────────────────────────────────────────────────────────────────────────────
void NotificationManager::CloseNotification(uint id)
{
    removeNotification(id, REASON_PROG);
}

void NotificationManager::dismissAll()
{
    const QList<Notification> copy = m_notifications;
    for (const Notification &n : copy)
        removeNotification(n.id, REASON_USER);
}

void NotificationManager::invokeAction(uint id, const QString &actionKey)
{
    emit ActionInvoked(id, actionKey);
    const Notification *n = findById(id);
    if (n && !n->resident)
        removeNotification(id, REASON_USER);
}

// ─────────────────────────────────────────────────────────────────────────────
void NotificationManager::expireNotification(uint id)
{
    removeNotification(id, REASON_EXPIRED);
}

void NotificationManager::removeNotification(uint id, uint reason)
{
    if (auto *t = m_timers.take(id)) { t->stop(); t->deleteLater(); }
    m_notifications.removeIf([id](const Notification &n) { return n.id == id; });
    emit NotificationClosed(id, reason);
    emit notificationsChanged();
}

Notification *NotificationManager::findById(uint id)
{
    for (Notification &n : m_notifications)
        if (n.id == id) return &n;
    return nullptr;
}
