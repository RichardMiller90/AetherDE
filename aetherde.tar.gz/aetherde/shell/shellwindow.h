#pragma once
// shell/shellwindow.h
// Base class for all shell surfaces (panel, launcher, notif overlay, lock screen)
// Uses wlr-layer-shell-unstable-v1 via the Qt Wayland client extension mechanism.
// SPDX-License-Identifier: MIT

#include <QWindow>
#include <QRect>
#include <QString>

// Forward-declare the client-side layer-shell interface wrapper
class LayerShellIntegration;

// ─────────────────────────────────────────────────────────────────────────────
class ShellWindow : public QWindow
{
    Q_OBJECT
    Q_PROPERTY(int exclusiveZone READ exclusiveZone WRITE setExclusiveZone)
    Q_PROPERTY(int marginTop     READ marginTop     WRITE setMarginTop)
    Q_PROPERTY(int marginBottom  READ marginBottom  WRITE setMarginBottom)
    Q_PROPERTY(int marginLeft    READ marginLeft    WRITE setMarginLeft)
    Q_PROPERTY(int marginRight   READ marginRight   WRITE setMarginRight)

public:
    enum class Layer {
        Background = 0,
        Bottom     = 1,
        Top        = 2,
        Overlay    = 3,
    };
    Q_ENUM(Layer)

    enum Anchor : uint32_t {
        AnchorNone   = 0,
        AnchorTop    = 1,
        AnchorBottom = 2,
        AnchorLeft   = 4,
        AnchorRight  = 8,
        AnchorFill   = 15,
    };
    Q_DECLARE_FLAGS(Anchors, Anchor)

    explicit ShellWindow(Layer layer     = Layer::Top,
                         Anchors anchors = AnchorNone,
                         QWindow *parent = nullptr);
    ~ShellWindow() override;

    Layer   layer()   const { return m_layer;   }
    Anchors anchors() const { return m_anchors; }

    int exclusiveZone() const { return m_exclusiveZone; }
    void setExclusiveZone(int z);

    int marginTop()    const { return m_marginTop;    }
    int marginBottom() const { return m_marginBottom; }
    int marginLeft()   const { return m_marginLeft;   }
    int marginRight()  const { return m_marginRight;  }
    void setMarginTop   (int v);
    void setMarginBottom(int v);
    void setMarginLeft  (int v);
    void setMarginRight (int v);

    // Keyboard interactivity
    enum class KbInteract { None = 0, Exclusive = 1, OnDemand = 2 };
    void setKeyboardInteractivity(KbInteract mode);

protected:
    void exposeEvent(QExposeEvent *) override;
    void resizeEvent(QResizeEvent *) override;

private:
    void applyLayerShell();

    Layer   m_layer;
    Anchors m_anchors;
    int     m_exclusiveZone = 0;
    int     m_marginTop     = 0;
    int     m_marginBottom  = 0;
    int     m_marginLeft    = 0;
    int     m_marginRight   = 0;
    KbInteract m_kbMode     = KbInteract::None;
    bool    m_layerApplied  = false;

    LayerShellIntegration *m_lsIntegration = nullptr;
};

Q_DECLARE_OPERATORS_FOR_FLAGS(ShellWindow::Anchors)
