#pragma once
// shell/systraymanager.h
// Implements StatusNotifierWatcher + StatusNotifierHost (FreeDesktop SNI spec)
// SPDX-License-Identifier: MIT

#include <QObject>
#include <QStringList>
#include <QVariantMap>
#include <QDBusInterface>
#include <QList>

// ─────────────────────────────────────────────────────────────────────────────
struct TrayItem {
    QString  service;       // e.g. "org.kde.StatusNotifierItem-1234-1"
    QString  objectPath;    // e.g. "/StatusNotifierItem"
    QString  id;
    QString  title;
    QString  iconName;
    QString  tooltipTitle;
    int      category = 0;  // 0=app, 1=comm, 2=sysservice, 3=hardware
    bool     itemIsMenu = false;
};

// ─────────────────────────────────────────────────────────────────────────────
class SysTrayManager : public QObject
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.kde.StatusNotifierWatcher")
    Q_PROPERTY(QList<TrayItem> items READ items NOTIFY itemsChanged)

public:
    explicit SysTrayManager(QObject *parent = nullptr);
    ~SysTrayManager() override;

    const QList<TrayItem>& items() const { return m_items; }

    // ── org.kde.StatusNotifierWatcher ─────────────────────────────────────────
    Q_INVOKABLE void RegisterStatusNotifierItem(const QString &serviceOrPath);
    Q_INVOKABLE void RegisterStatusNotifierHost(const QString &service);

    Q_INVOKABLE QStringList RegisteredStatusNotifierItems() const;
    Q_INVOKABLE bool        IsStatusNotifierHostRegistered() const;
    Q_INVOKABLE int         ProtocolVersion() const { return 0; }

    // QML
    Q_INVOKABLE void activate(const QString &service, int x, int y);
    Q_INVOKABLE void secondaryActivate(const QString &service, int x, int y);
    Q_INVOKABLE void scroll(const QString &service, int delta, const QString &orientation);

signals:
    // SNI Watcher signals
    void StatusNotifierItemRegistered(const QString &service);
    void StatusNotifierItemUnregistered(const QString &service);
    void StatusNotifierHostRegistered();
    void StatusNotifierHostUnregistered();

    // Internal
    void itemsChanged();

private slots:
    void onServiceUnregistered(const QString &service);
    void fetchItemProperties(const QString &service, const QString &path);

private:
    QList<TrayItem>     m_items;
    QStringList         m_registeredServices;
    bool                m_hostRegistered = false;

    TrayItem *findByService(const QString &service);
    void removeByService(const QString &service);
};
