#pragma once
// shell/wallpapermanager.h
// SPDX-License-Identifier: MIT

#include <QObject>
#include <QString>
#include <QStringList>
#include <QTimer>
#include <QVariantMap>

class QSettings;

class WallpaperManager : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString  currentPath  READ currentPath  NOTIFY wallpaperChanged)
    Q_PROPERTY(QString  fillMode     READ fillMode     WRITE setFillMode     NOTIFY settingsChanged)
    Q_PROPERTY(bool     slideshowOn  READ slideshowOn  WRITE setSlideshowOn  NOTIFY settingsChanged)
    Q_PROPERTY(int      slideshowSec READ slideshowSec WRITE setSlideshowSec NOTIFY settingsChanged)

public:
    explicit WallpaperManager(QObject *parent = nullptr);
    ~WallpaperManager() override;

    QString currentPath()  const { return m_current;      }
    QString fillMode()     const { return m_fillMode;     }
    bool    slideshowOn()  const { return m_slideshowOn;  }
    int     slideshowSec() const { return m_slideshowSec; }

    Q_INVOKABLE void setWallpaper(const QString &path);
    Q_INVOKABLE void addSlideshowDir(const QString &dir);
    Q_INVOKABLE void next();
    Q_INVOKABLE void prev();

    void setFillMode(const QString &mode);
    void setSlideshowOn(bool on);
    void setSlideshowSec(int secs);

signals:
    void wallpaperChanged(const QString &path);
    void settingsChanged();

private:
    void loadSettings();
    void saveSettings();
    void scanDir(const QString &dir);
    void applyIndex(int idx);

    QString     m_current;
    QString     m_fillMode     = QStringLiteral("PreserveAspectCrop");
    bool        m_slideshowOn  = false;
    int         m_slideshowSec = 300;
    QStringList m_slides;
    int         m_slideIndex   = 0;
    QTimer      m_timer;
    QSettings  *m_settings     = nullptr;
};
