#pragma once
// shell/desktopmodel.h
// SPDX-License-Identifier: MIT

#include <QAbstractListModel>
#include <QList>
#include <QString>
#include <QIcon>
#include <QFileSystemWatcher>

// ─────────────────────────────────────────────────────────────────────────────
struct DesktopEntry {
    QString id;           // basename without .desktop
    QString name;
    QString genericName;
    QString comment;
    QString exec;
    QString tryExec;
    QString icon;
    QString categories;
    bool    terminal    = false;
    bool    noDisplay   = false;
    bool    hidden      = false;
};

// ─────────────────────────────────────────────────────────────────────────────
class DesktopModel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(int count READ rowCount NOTIFY layoutChanged)
    Q_PROPERTY(QString filter READ filter WRITE setFilter NOTIFY filterChanged)

public:
    enum Roles {
        IdRole = Qt::UserRole + 1,
        NameRole,
        GenericNameRole,
        CommentRole,
        ExecRole,
        IconNameRole,
        CategoriesRole,
        TerminalRole,
    };

    explicit DesktopModel(QObject *parent = nullptr);

    // QAbstractListModel
    int      rowCount(const QModelIndex &parent = {}) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;

    QString filter() const { return m_filter; }
    void    setFilter(const QString &f);

    Q_INVOKABLE void launch(const QString &id) const;
    Q_INVOKABLE void launchExec(const QString &exec, bool terminal) const;

signals:
    void filterChanged();

public slots:
    void reload();

private:
    void parseDesktopFile(const QString &path);
    QList<DesktopEntry> applyFilter() const;

    QList<DesktopEntry>  m_entries;
    QList<DesktopEntry>  m_filtered;
    QString              m_filter;
    QFileSystemWatcher   m_watcher;
};
