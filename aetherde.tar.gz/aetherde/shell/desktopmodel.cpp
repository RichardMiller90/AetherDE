// shell/desktopmodel.cpp
// SPDX-License-Identifier: MIT

#include "desktopmodel.h"

#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QStandardPaths>
#include <QProcess>
#include <QRegularExpression>
#include <QLoggingCategory>
#include <algorithm>

Q_LOGGING_CATEGORY(lcDesktop, "aether.desktop")

// ─────────────────────────────────────────────────────────────────────────────
DesktopModel::DesktopModel(QObject *parent)
    : QAbstractListModel(parent)
{
    // Watch all XDG application dirs for changes
    const QStringList appDirs = QStandardPaths::standardLocations(
        QStandardPaths::ApplicationsLocation);
    for (const QString &d : appDirs) {
        m_watcher.addPath(d);
    }
    connect(&m_watcher, &QFileSystemWatcher::directoryChanged,
            this, &DesktopModel::reload);

    reload();
}

// ─────────────────────────────────────────────────────────────────────────────
void DesktopModel::reload()
{
    beginResetModel();
    m_entries.clear();

    const QStringList appDirs = QStandardPaths::standardLocations(
        QStandardPaths::ApplicationsLocation);

    // Also check /usr/local/share/applications (FreeBSD ports)
    QStringList dirs = appDirs;
    dirs << QStringLiteral("/usr/local/share/applications");
    dirs.removeDuplicates();

    QSet<QString> seen;
    for (const QString &dir : dirs) {
        QDir d(dir);
        if (!d.exists()) continue;
        const QStringList files = d.entryList({"*.desktop"}, QDir::Files);
        for (const QString &f : files) {
            if (seen.contains(f)) continue;
            seen.insert(f);
            parseDesktopFile(d.absoluteFilePath(f));
        }
    }

    // Sort alphabetically
    std::sort(m_entries.begin(), m_entries.end(),
              [](const DesktopEntry &a, const DesktopEntry &b) {
                  return a.name.toLower() < b.name.toLower();
              });

    m_filtered = applyFilter();
    endResetModel();

    qCDebug(lcDesktop) << "Loaded" << m_entries.size() << ".desktop entries";
}

// ─────────────────────────────────────────────────────────────────────────────
void DesktopModel::parseDesktopFile(const QString &path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) return;

    QTextStream in(&file);
    DesktopEntry entry;
    entry.id = QFileInfo(path).baseName();

    bool inDesktopEntry = false;
    while (!in.atEnd()) {
        const QString line = in.readLine().trimmed();
        if (line.startsWith('#') || line.isEmpty()) continue;
        if (line.startsWith('[')) {
            inDesktopEntry = (line == "[Desktop Entry]");
            continue;
        }
        if (!inDesktopEntry) continue;

        const int eq = line.indexOf('=');
        if (eq < 0) continue;
        const QString key   = line.left(eq).trimmed();
        const QString value = line.mid(eq + 1).trimmed();

        // Locale-aware: prefer e.g. Name[en] if we could detect locale,
        // but for simplicity we use the generic key.
        if      (key == "Name"        ) entry.name        = value;
        else if (key == "GenericName" ) entry.genericName  = value;
        else if (key == "Comment"     ) entry.comment      = value;
        else if (key == "Exec"        ) entry.exec         = value;
        else if (key == "TryExec"     ) entry.tryExec      = value;
        else if (key == "Icon"        ) entry.icon         = value;
        else if (key == "Categories"  ) entry.categories   = value;
        else if (key == "Terminal"    ) entry.terminal     = (value.toLower() == "true");
        else if (key == "NoDisplay"   ) entry.noDisplay    = (value.toLower() == "true");
        else if (key == "Hidden"      ) entry.hidden       = (value.toLower() == "true");
    }

    if (entry.name.isEmpty() || entry.exec.isEmpty()) return;
    if (entry.noDisplay || entry.hidden) return;

    m_entries.append(entry);
}

// ─────────────────────────────────────────────────────────────────────────────
QList<DesktopEntry> DesktopModel::applyFilter() const
{
    if (m_filter.isEmpty()) return m_entries;
    const QString fl = m_filter.toLower();
    QList<DesktopEntry> out;
    for (const DesktopEntry &e : m_entries) {
        if (e.name.toLower().contains(fl)
         || e.genericName.toLower().contains(fl)
         || e.comment.toLower().contains(fl)
         || e.categories.toLower().contains(fl))
            out.append(e);
    }
    return out;
}

void DesktopModel::setFilter(const QString &f)
{
    if (m_filter == f) return;
    m_filter = f;
    beginResetModel();
    m_filtered = applyFilter();
    endResetModel();
    emit filterChanged();
}

// ─────────────────────────────────────────────────────────────────────────────
int DesktopModel::rowCount(const QModelIndex &parent) const
{
    if (parent.isValid()) return 0;
    return m_filtered.size();
}

QVariant DesktopModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() >= m_filtered.size())
        return {};
    const DesktopEntry &e = m_filtered.at(index.row());
    switch (role) {
    case IdRole:          return e.id;
    case NameRole:        return e.name;
    case GenericNameRole: return e.genericName;
    case CommentRole:     return e.comment;
    case ExecRole:        return e.exec;
    case IconNameRole:    return e.icon;
    case CategoriesRole:  return e.categories;
    case TerminalRole:    return e.terminal;
    default:              return {};
    }
}

QHash<int, QByteArray> DesktopModel::roleNames() const
{
    return {
        { IdRole,          "appId"       },
        { NameRole,        "name"        },
        { GenericNameRole, "genericName" },
        { CommentRole,     "comment"     },
        { ExecRole,        "exec"        },
        { IconNameRole,    "iconName"    },
        { CategoriesRole,  "categories"  },
        { TerminalRole,    "terminal"    },
    };
}

// ─────────────────────────────────────────────────────────────────────────────
void DesktopModel::launch(const QString &id) const
{
    for (const DesktopEntry &e : m_entries) {
        if (e.id == id) {
            launchExec(e.exec, e.terminal);
            return;
        }
    }
    qCWarning(lcDesktop) << "App not found:" << id;
}

void DesktopModel::launchExec(const QString &exec, bool terminal) const
{
    // Strip field codes (%u, %f, %F, %U, %i, %c, %k …)
    static const QRegularExpression fieldCodes("%[uUfFdDnNickvm]");
    QString cmd = exec;
    cmd.remove(fieldCodes).simplified();

    QStringList args;
    if (terminal) {
        // Prefer an available terminal emulator
        for (const QString &term : {"alacritty", "xterm", "kitty", "konsole", "xfce4-terminal"}) {
            if (!QStandardPaths::findExecutable(term).isEmpty()) {
                args = QStringList{"-e", "sh", "-c", cmd};
                cmd  = term;
                break;
            }
        }
    }

    qCDebug(lcDesktop) << "Launch:" << cmd << args;
    QProcess::startDetached(cmd, args);
}
