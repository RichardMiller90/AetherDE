// shell/main.cpp  –  AetherDE Shell (Wayland client)
// Provides: top panel, taskbar, launcher, notifications, system tray
// SPDX-License-Identifier: MIT

#include "shellwindow.h"
#include "panelwindow.h"
#include "launcherpopup.h"
#include "notificationmanager.h"
#include "systraymanager.h"
#include "desktopmodel.h"
#include "wallpapermanager.h"
#include "statusmonitor.h"
#include "foreigntoplevelmodel.h"
#include "shellquickwindow.h"
#include "dbus/shelldbusadaptor.h"

#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QIcon>
#include <QDir>
#include <QStandardPaths>
#include <QDBusConnection>
#include <QLoggingCategory>

Q_LOGGING_CATEGORY(lcShell, "aether.shell")

int main(int argc, char *argv[])
{
    // We are a Wayland client
    qputenv("QT_QPA_PLATFORM", "wayland");
    qputenv("QT_WAYLAND_DISABLE_WINDOWDECORATION", "1");
    qputenv("QT_QUICK_CONTROLS_STYLE", "Basic");

    QGuiApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("AetherDE Shell"));
    app.setApplicationVersion(AETHER_VERSION);
    app.setOrganizationName(QStringLiteral("AetherDE"));
    app.setWindowIcon(QIcon::fromTheme("aetherde"));

    // ── Core services ──────────────────────────────────────────────────────────
    DesktopModel       desktopModel;
    NotificationManager notifMgr;
    SysTrayManager     trayMgr;
    WallpaperManager       wallpaperMgr;
    StatusMonitor          statusMonitor;
    ForeignToplevelModel   toplevelModel;

    // ── D-Bus: expose shell API to other processes ─────────────────────────────
    ShellDBusAdaptor dbusAdaptor(&desktopModel, &notifMgr);
    QDBusConnection::sessionBus().registerObject("/org/AetherDE/Shell", &dbusAdaptor,
        QDBusConnection::ExportAllSlots | QDBusConnection::ExportAllSignals);
    QDBusConnection::sessionBus().registerService("org.AetherDE.Shell");

    // ── QML engine ────────────────────────────────────────────────────────────
    QQmlApplicationEngine engine;

    // Expose C++ objects to QML
    engine.rootContext()->setContextProperty("desktopModel",   &desktopModel);
    engine.rootContext()->setContextProperty("notifManager",   &notifMgr);
    engine.rootContext()->setContextProperty("trayManager",    &trayMgr);
    engine.rootContext()->setContextProperty("wallpaperMgr",   &wallpaperMgr);
    engine.rootContext()->setContextProperty("statusMonitor",  &statusMonitor);
    engine.rootContext()->setContextProperty("toplevelModel",  &toplevelModel);
    engine.rootContext()->setContextProperty("dataDir",
        QString::fromUtf8(AETHER_DATADIR));

    // QML import paths
    engine.addImportPath(QStringLiteral(AETHER_DATADIR) + "/qml");

    // Try installed QML first, fall back to source tree
    const QString qmlInstalled = QStringLiteral(AETHER_DATADIR) + "/shell/shell.qml";
    const QString qmlSource    = QStringLiteral(SOURCE_DIR "/qml/shell.qml");
    const QUrl    qmlUrl = QFile::exists(qmlInstalled)
                         ? QUrl::fromLocalFile(qmlInstalled)
                         : QFile::exists(qmlSource)
                           ? QUrl::fromLocalFile(qmlSource)
                           : QUrl(QStringLiteral("qrc:/shell/shell.qml"));

    // Register C++ types with QML engine
    ShellQuickWindow::registerQmlType();

    engine.load(qmlUrl);
    if (engine.rootObjects().isEmpty()) {
        qCCritical(lcShell) << "Failed to load shell QML:" << qmlUrl;
        return 1;
    }

    qCInfo(lcShell) << "AetherDE Shell started";
    return app.exec();
}
