// shell/systraymanager.cpp
// SPDX-License-Identifier: MIT

#include "systraymanager.h"

#include <QDBusConnection>
#include <QDBusServiceWatcher>
#include <QDBusInterface>
#include <QDBusReply>
#include <QLoggingCategory>

Q_LOGGING_CATEGORY(lcTray, "aether.systray")

// ─────────────────────────────────────────────────────────────────────────────
SysTrayManager::SysTrayManager(QObject *parent)
    : QObject(parent)
{
    auto &bus = QDBusConnection::sessionBus();

    // Register as StatusNotifierWatcher
    bus.registerObject("/StatusNotifierWatcher", this,
        QDBusConnection::ExportAllSlots | QDBusConnection::ExportAllSignals
      | QDBusConnection::ExportAllProperties);
    bus.registerService("org.kde.StatusNotifierWatcher");

    // Watch for SNI services disappearing
    auto *watcher = new QDBusServiceWatcher(this);
    watcher->setConnection(bus);
    watcher->setWatchMode(QDBusServiceWatcher::WatchForUnregistration);
    connect(watcher, &QDBusServiceWatcher::serviceUnregistered,
            this, &SysTrayManager::onServiceUnregistered);

    qCInfo(lcTray) << "StatusNotifierWatcher registered";
}

SysTrayManager::~SysTrayManager() = default;

// ─────────────────────────────────────────────────────────────────────────────
void SysTrayManager::RegisterStatusNotifierItem(const QString &serviceOrPath)
{
    QString service, path;
    if (serviceOrPath.startsWith('/')) {
        // Called with object path; extract service from D-Bus message sender
        service = message().service();   // QDBusContext method
        path    = serviceOrPath;
    } else {
        service = serviceOrPath;
        path    = "/StatusNotifierItem";
    }

    if (m_registeredServices.contains(service)) return;

    m_registeredServices.append(service);
    emit StatusNotifierItemRegistered(service);

    fetchItemProperties(service, path);

    qCDebug(lcTray) << "SNI registered:" << service << path;
}

void SysTrayManager::RegisterStatusNotifierHost(const QString &service)
{
    m_hostRegistered = true;
    emit StatusNotifierHostRegistered();
    qCDebug(lcTray) << "SNI host registered:" << service;
}

QStringList SysTrayManager::RegisteredStatusNotifierItems() const
{
    return m_registeredServices;
}

bool SysTrayManager::IsStatusNotifierHostRegistered() const
{
    return m_hostRegistered;
}

// ─────────────────────────────────────────────────────────────────────────────
void SysTrayManager::fetchItemProperties(const QString &service, const QString &path)
{
    QDBusInterface iface(service, path,
                         "org.kde.StatusNotifierItem",
                         QDBusConnection::sessionBus());
    if (!iface.isValid()) {
        qCWarning(lcTray) << "SNI interface invalid for" << service;
        return;
    }

    TrayItem item;
    item.service    = service;
    item.objectPath = path;
    item.id         = iface.property("Id").toString();
    item.title      = iface.property("Title").toString();
    item.iconName   = iface.property("IconName").toString();
    item.category   = iface.property("Category").toString() == "ApplicationStatus" ? 0
                    : iface.property("Category").toString() == "Communications"    ? 1
                    : iface.property("Category").toString() == "SystemServices"    ? 2
                    : 3; // HardwareControl
    item.itemIsMenu = iface.property("ItemIsMenu").toBool();

    const QVariantMap ttMap = iface.property("ToolTip").toMap();
    item.tooltipTitle = ttMap.value("title").toString();

    m_items.append(item);
    emit itemsChanged();
}

// ─────────────────────────────────────────────────────────────────────────────
void SysTrayManager::onServiceUnregistered(const QString &service)
{
    if (!m_registeredServices.contains(service)) return;
    m_registeredServices.removeAll(service);
    removeByService(service);
    emit StatusNotifierItemUnregistered(service);
    emit itemsChanged();
    qCDebug(lcTray) << "SNI unregistered:" << service;
}

// ─────────────────────────────────────────────────────────────────────────────
void SysTrayManager::activate(const QString &service, int x, int y)
{
    QDBusInterface iface(service, "/StatusNotifierItem",
                         "org.kde.StatusNotifierItem",
                         QDBusConnection::sessionBus());
    iface.asyncCall("Activate", x, y);
}

void SysTrayManager::secondaryActivate(const QString &service, int x, int y)
{
    QDBusInterface iface(service, "/StatusNotifierItem",
                         "org.kde.StatusNotifierItem",
                         QDBusConnection::sessionBus());
    iface.asyncCall("SecondaryActivate", x, y);
}

void SysTrayManager::scroll(const QString &service, int delta, const QString &orientation)
{
    QDBusInterface iface(service, "/StatusNotifierItem",
                         "org.kde.StatusNotifierItem",
                         QDBusConnection::sessionBus());
    iface.asyncCall("Scroll", delta, orientation);
}

// ─────────────────────────────────────────────────────────────────────────────
TrayItem *SysTrayManager::findByService(const QString &service)
{
    for (TrayItem &item : m_items)
        if (item.service == service) return &item;
    return nullptr;
}

void SysTrayManager::removeByService(const QString &service)
{
    m_items.removeIf([&](const TrayItem &i) { return i.service == service; });
}
