#pragma once
// shell/foreigntoplevelmodel.h
// Implements the ext-foreign-toplevel-list-v1 Wayland protocol to enumerate
// all compositor toplevel windows from the shell client.
// SPDX-License-Identifier: MIT

#include <QAbstractListModel>
#include <QString>
#include <QList>

struct wl_registry;
struct ext_foreign_toplevel_list_v1;
struct ext_foreign_toplevel_handle_v1;

// ─────────────────────────────────────────────────────────────────────────────
class ToplevelHandle : public QObject
{
    Q_OBJECT
public:
    explicit ToplevelHandle(ext_foreign_toplevel_handle_v1 *handle, QObject *parent = nullptr);
    ~ToplevelHandle() override;

    QString  title()     const { return m_title;     }
    QString  appId()     const { return m_appId;     }
    bool     active()    const { return m_active;    }
    bool     minimized() const { return m_minimized; }

    Q_INVOKABLE void activate();
    Q_INVOKABLE void close();
    Q_INVOKABLE void minimize();
    Q_INVOKABLE void unminimize();
    Q_INVOKABLE void maximize();
    Q_INVOKABLE void unmaximize();
    Q_INVOKABLE void fullscreen();
    Q_INVOKABLE void unfullscreen();

    ext_foreign_toplevel_handle_v1 *nativeHandle() const { return m_handle; }

    // Called from wayland listener callbacks
    void setTitle(const QString &t)     { m_title     = t; }
    void setAppId(const QString &id)    { m_appId     = id; }
    void setActive(bool a)              { m_active    = a; }
    void setMinimized(bool m)           { m_minimized = m; }

signals:
    void changed();
    void closed();

private:
    ext_foreign_toplevel_handle_v1 *m_handle;
    QString m_title;
    QString m_appId;
    bool    m_active    = false;
    bool    m_minimized = false;
};

// ─────────────────────────────────────────────────────────────────────────────
class ForeignToplevelModel : public QAbstractListModel
{
    Q_OBJECT
public:
    enum Roles {
        TitleRole = Qt::UserRole + 1,
        AppIdRole,
        ActiveRole,
        MinimizedRole,
        HandleRole,
    };

    explicit ForeignToplevelModel(QObject *parent = nullptr);
    ~ForeignToplevelModel() override;

    int      rowCount(const QModelIndex &parent = {}) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;

    // Called from wayland listener
    void addToplevel(ToplevelHandle *handle);
    void removeToplevel(ToplevelHandle *handle);
    void toplevelChanged(ToplevelHandle *handle);

private:
    void init();

    ext_foreign_toplevel_list_v1 *m_manager = nullptr;
    QList<ToplevelHandle*>        m_toplevels;
};
