#pragma once
// shell/notificationmanager.h
// Implements the org.freedesktop.Notifications D-Bus interface (spec v1.2)
// SPDX-License-Identifier: MIT

#include <QObject>
#include <QVariantMap>
#include <QList>
#include <QTimer>
#include <QStringList>

// ─────────────────────────────────────────────────────────────────────────────
struct Notification {
    uint        id         = 0;
    QString     appName;
    QString     appIcon;
    QString     summary;
    QString     body;
    QStringList actions;   // ["action-key", "Display Label", …]
    QVariantMap hints;
    int         timeout    = -1;   // ms; -1 = server default, 0 = never
    int         urgency    = 1;    // 0=low, 1=normal, 2=critical
    QString     soundFile;
    bool        resident   = false;
    bool        transient  = false;
};

// ─────────────────────────────────────────────────────────────────────────────
class NotificationManager : public QObject
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.freedesktop.Notifications")
    Q_PROPERTY(QList<Notification> notifications READ notifications NOTIFY notificationsChanged)

public:
    explicit NotificationManager(QObject *parent = nullptr);
    ~NotificationManager() override;

    const QList<Notification>& notifications() const { return m_notifications; }

    // ── org.freedesktop.Notifications interface ──────────────────────────────
    Q_INVOKABLE QStringList GetCapabilities();

    Q_INVOKABLE uint Notify(const QString  &app_name,
                            uint            replaces_id,
                            const QString  &app_icon,
                            const QString  &summary,
                            const QString  &body,
                            const QStringList &actions,
                            const QVariantMap &hints,
                            int             expire_timeout);

    Q_INVOKABLE void CloseNotification(uint id);

    Q_INVOKABLE void GetServerInformation(QString &name, QString &vendor,
                                          QString &version, QString &spec_version);

    // QML helpers
    Q_INVOKABLE void dismissAll();
    Q_INVOKABLE void invokeAction(uint id, const QString &actionKey);

signals:
    // D-Bus signals
    void NotificationClosed(uint id, uint reason);
    void ActionInvoked(uint id, const QString &action_key);

    // Internal / QML
    void notificationsChanged();
    void newNotification(uint id);

private slots:
    void expireNotification(uint id);

private:
    uint                 m_nextId = 1;
    QList<Notification>  m_notifications;
    QHash<uint, QTimer*> m_timers;

    void removeNotification(uint id, uint reason);
    Notification *findById(uint id);
};
