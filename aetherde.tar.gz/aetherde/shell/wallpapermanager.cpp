// shell/wallpapermanager.cpp
// SPDX-License-Identifier: MIT

#include "wallpapermanager.h"

#include <QSettings>
#include <QDir>
#include <QFileInfo>
#include <QStandardPaths>
#include <QMimeDatabase>
#include <QLoggingCategory>
#include <algorithm>
#include <random>

Q_LOGGING_CATEGORY(lcWallpaper, "aether.wallpaper")

static const QStringList IMAGE_EXTS = {"jpg","jpeg","png","webp","bmp","gif","tiff"};

// ─────────────────────────────────────────────────────────────────────────────
WallpaperManager::WallpaperManager(QObject *parent)
    : QObject(parent)
    , m_settings(new QSettings(QStringLiteral("AetherDE"), QStringLiteral("wallpaper"), this))
{
    connect(&m_timer, &QTimer::timeout, this, &WallpaperManager::next);
    loadSettings();
}

WallpaperManager::~WallpaperManager()
{
    saveSettings();
}

// ─────────────────────────────────────────────────────────────────────────────
void WallpaperManager::loadSettings()
{
    m_current      = m_settings->value("current").toString();
    m_fillMode     = m_settings->value("fillMode", "PreserveAspectCrop").toString();
    m_slideshowOn  = m_settings->value("slideshowOn", false).toBool();
    m_slideshowSec = m_settings->value("slideshowSec", 300).toInt();

    const QStringList dirs = m_settings->value("slideshowDirs").toStringList();
    for (const QString &d : dirs) scanDir(d);

    if (!m_current.isEmpty()) emit wallpaperChanged(m_current);

    if (m_slideshowOn) {
        m_timer.setInterval(m_slideshowSec * 1000);
        m_timer.start();
    }
}

void WallpaperManager::saveSettings()
{
    m_settings->setValue("current",      m_current);
    m_settings->setValue("fillMode",     m_fillMode);
    m_settings->setValue("slideshowOn",  m_slideshowOn);
    m_settings->setValue("slideshowSec", m_slideshowSec);
}

// ─────────────────────────────────────────────────────────────────────────────
void WallpaperManager::scanDir(const QString &dir)
{
    QDir d(dir);
    if (!d.exists()) return;

    QStringList filters;
    for (const QString &ext : IMAGE_EXTS)
        filters << "*." + ext << "*." + ext.toUpper();

    const QStringList files = d.entryList(filters, QDir::Files, QDir::Name);
    for (const QString &f : files)
        m_slides.append(d.absoluteFilePath(f));

    m_slides.removeDuplicates();
    qCDebug(lcWallpaper) << "Scanned" << dir << "→" << m_slides.size() << "slides";
}

// ─────────────────────────────────────────────────────────────────────────────
void WallpaperManager::setWallpaper(const QString &path)
{
    if (m_current == path) return;
    m_current = path;
    saveSettings();
    emit wallpaperChanged(m_current);
    qCDebug(lcWallpaper) << "Wallpaper set:" << path;
}

void WallpaperManager::addSlideshowDir(const QString &dir)
{
    scanDir(dir);
    QStringList dirs = m_settings->value("slideshowDirs").toStringList();
    if (!dirs.contains(dir)) {
        dirs << dir;
        m_settings->setValue("slideshowDirs", dirs);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
void WallpaperManager::applyIndex(int idx)
{
    if (m_slides.isEmpty()) return;
    m_slideIndex = ((idx % m_slides.size()) + m_slides.size()) % m_slides.size();
    setWallpaper(m_slides.at(m_slideIndex));
}

void WallpaperManager::next() { applyIndex(m_slideIndex + 1); }
void WallpaperManager::prev() { applyIndex(m_slideIndex - 1); }

// ─────────────────────────────────────────────────────────────────────────────
void WallpaperManager::setFillMode(const QString &mode)
{
    if (m_fillMode == mode) return;
    m_fillMode = mode;
    saveSettings();
    emit settingsChanged();
}

void WallpaperManager::setSlideshowOn(bool on)
{
    if (m_slideshowOn == on) return;
    m_slideshowOn = on;
    if (on) { m_timer.setInterval(m_slideshowSec * 1000); m_timer.start(); }
    else    { m_timer.stop(); }
    saveSettings();
    emit settingsChanged();
}

void WallpaperManager::setSlideshowSec(int secs)
{
    if (m_slideshowSec == secs) return;
    m_slideshowSec = qMax(5, secs);
    if (m_timer.isActive()) m_timer.setInterval(m_slideshowSec * 1000);
    saveSettings();
    emit settingsChanged();
}
