// shell/shellquickwindow.cpp
// SPDX-License-Identifier: MIT

#include "shellquickwindow.h"
#include <QQmlEngine>
#include <QLoggingCategory>

Q_LOGGING_CATEGORY(lcSQW, "aether.shellquickwindow")

// ─────────────────────────────────────────────────────────────────────────────
ShellQuickWindow::ShellQuickWindow(QWindow *parent)
    : QQuickWindow(parent)
{
    setFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint);
    setColor(Qt::transparent);
}

ShellQuickWindow::~ShellQuickWindow() = default;

// ─────────────────────────────────────────────────────────────────────────────
void ShellQuickWindow::exposeEvent(QExposeEvent *ev)
{
    QQuickWindow::exposeEvent(ev);
    if (!m_applied && isExposed())
        applyLayerShell();
}

void ShellQuickWindow::applyLayerShell()
{
    // Create the ShellWindow helper (it does all the wl_surface plumbing)
    m_helper = new ShellWindow(m_layer,
                               ShellWindow::Anchors(static_cast<uint>(m_anchors)),
                               this);
    m_helper->setExclusiveZone(m_exclZone);
    m_helper->setMarginTop(m_mTop);
    m_helper->setMarginBottom(m_mBottom);
    m_helper->setMarginLeft(m_mLeft);
    m_helper->setMarginRight(m_mRight);
    m_helper->setKeyboardInteractivity(m_kbMode);

    // ShellWindow wraps the wl_surface already assigned to *this* QQuickWindow
    // via the Qt Wayland platform plugin.  We pass our native handle directly
    // so applyLayerShell() in ShellWindow picks it up.
    m_applied = true;
    qCDebug(lcSQW) << "LayerWindow applied layer=" << (int)m_layer
                   << "anchors=" << m_anchors;
}

// ─────────────────────────────────────────────────────────────────────────────
void ShellQuickWindow::setLayer(int l)
{
    m_layer = static_cast<ShellWindow::Layer>(l);
    if (m_helper) { /* re-apply not currently supported; requires destroy/recreate */ }
}
void ShellQuickWindow::setAnchors(int a)        { m_anchors  = static_cast<ShellWindow::Anchor>(a); }
void ShellQuickWindow::setExclusiveZone(int z)  { m_exclZone = z; if (m_helper) m_helper->setExclusiveZone(z); }
void ShellQuickWindow::setMarginTop(int v)      { m_mTop     = v; if (m_helper) m_helper->setMarginTop(v);     }
void ShellQuickWindow::setMarginBottom(int v)   { m_mBottom  = v; if (m_helper) m_helper->setMarginBottom(v);  }
void ShellQuickWindow::setMarginLeft(int v)     { m_mLeft    = v; if (m_helper) m_helper->setMarginLeft(v);    }
void ShellQuickWindow::setMarginRight(int v)    { m_mRight   = v; if (m_helper) m_helper->setMarginRight(v);   }
void ShellQuickWindow::setKbInteract(int m)     { m_kbMode   = static_cast<ShellWindow::KbInteract>(m);        }

// ─────────────────────────────────────────────────────────────────────────────
void ShellQuickWindow::registerQmlType()
{
    qmlRegisterType<ShellQuickWindow>("AetherShell", 1, 0, "ShellQuickWindow");
}
