// session/main.cpp  –  AetherDE Session Manager
//
// Responsibilities
//   • Acquire the DRM/input seat via libseat (unprivileged) or direct open
//   • Authenticate the user with PAM (if invoked from a display manager)
//   • Set up the environment (WAYLAND_DISPLAY, XDG_* vars, DBUS_SESSION_BUS)
//   • Start the compositor and shell, restart them on crash
//   • Implement org.AetherDE.Session D-Bus interface (logout / reboot / shutdown)
//
// SPDX-License-Identifier: MIT

#include "sessionmanager.h"

#include <QCoreApplication>
#include <QCommandLineParser>
#include <QDBusConnection>
#include <QLoggingCategory>
#include <QTextStream>
#include <cstdlib>

Q_LOGGING_CATEGORY(lcSess, "aether.session")

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);
    app.setApplicationName("AetherDE Session Manager");
    app.setApplicationVersion(AETHER_VERSION);
    app.setOrganizationName("AetherDE");

    QCommandLineParser parser;
    parser.setApplicationDescription("AetherDE Session Manager");
    parser.addHelpOption();
    parser.addVersionOption();

    QCommandLineOption userOpt({"u","user"}, "Username to open session for", "user",
                               QString::fromLocal8Bit(qgetenv("USER")));
    QCommandLineOption vt({"t","vt"}, "Virtual terminal number", "vt", "1");
    QCommandLineOption noPam("no-pam", "Skip PAM authentication");
    parser.addOptions({userOpt, vt, noPam});
    parser.process(app);

    // ── Session D-Bus service ──────────────────────────────────────────────────
    if (!QDBusConnection::sessionBus().isConnected()) {
        // Launch dbus-daemon if not already running
        qCWarning(lcSess) << "Session bus not available; attempting to start dbus-daemon";
        if (system("dbus-launch --sh-syntax > /tmp/aether-dbus.env") == 0) {
            // Source the env file
            QFile envFile("/tmp/aether-dbus.env");
            if (envFile.open(QIODevice::ReadOnly)) {
                QTextStream s(&envFile);
                while (!s.atEnd()) {
                    const QString line = s.readLine().trimmed();
                    if (line.startsWith("DBUS_SESSION_BUS_ADDRESS=")) {
                        const QString addr = line.section('=', 1).remove('"').remove(';');
                        qputenv("DBUS_SESSION_BUS_ADDRESS", addr.toLocal8Bit());
                    }
                }
            }
        }
    }

    SessionManager session;
    session.setUsername(parser.value(userOpt));
    session.setVt(parser.value(vt).toInt());
    session.setSkipPam(parser.isSet(noPam));

    QDBusConnection::sessionBus().registerObject("/org/AetherDE/Session", &session,
        QDBusConnection::ExportAllSlots | QDBusConnection::ExportAllSignals);
    QDBusConnection::sessionBus().registerService("org.AetherDE.Session");

    if (!session.start()) {
        qCCritical(lcSess) << "Session failed to start";
        return 1;
    }

    qCInfo(lcSess) << "AetherDE Session Manager running for user" << parser.value(userOpt);
    return app.exec();
}
