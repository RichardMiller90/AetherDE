#pragma once
// session/sessionmanager.h
// SPDX-License-Identifier: MIT

#include <QObject>
#include <QProcess>
#include <QString>
#include <QHash>

// ─────────────────────────────────────────────────────────────────────────────
class SessionManager : public QObject
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.AetherDE.Session")

public:
    explicit SessionManager(QObject *parent = nullptr);
    ~SessionManager() override;

    void setUsername(const QString &u) { m_username = u; }
    void setVt(int vt)                 { m_vt = vt;      }
    void setSkipPam(bool s)            { m_skipPam = s;   }

    bool start();

    // ── D-Bus interface ────────────────────────────────────────────────────────
public slots:
    void requestLogout();
    void requestShutdown();
    void requestReboot();
    void requestSuspend();
    void requestHibernate();
    void requestLockScreen();
    void requestRelaunchShell();

signals:
    void sessionEnding(const QString &reason);
    void lockScreenRequested();

private slots:
    void onCompositorFinished(int code, QProcess::ExitStatus status);
    void onShellFinished(int code, QProcess::ExitStatus status);

private:
    void setupEnvironment();
    void launchCompositor();
    void launchShell();
    bool pamAuthenticate();
    void logindCall(const QString &method, bool interactive = false);
    void restartProcess(QProcess *proc, const QString &name,
                        const QStringList &args, int delayMs = 1000);

    QString   m_username;
    int       m_vt        = 1;
    bool      m_skipPam   = false;
    bool      m_stopping  = false;

    QProcess *m_compositor = nullptr;
    QProcess *m_shell      = nullptr;

    int       m_compositorCrashes = 0;
    int       m_shellCrashes      = 0;

    static constexpr int MAX_CRASHES = 5;
};
