// session/sessionmanager.cpp
// SPDX-License-Identifier: MIT

#include "sessionmanager.h"

#include <QCoreApplication>
#include <QDBusConnection>
#include <QDBusInterface>
#include <QDBusMessage>
#include <QTimer>
#include <QDir>
#include <QStandardPaths>
#include <QLoggingCategory>

extern "C" {
#ifdef __linux__
#  include <security/pam_appl.h>
#endif
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>
}

Q_LOGGING_CATEGORY(lcSession, "aether.session")

// ─────────────────────────────────────────────────────────────────────────────
SessionManager::SessionManager(QObject *parent)
    : QObject(parent)
{
}

SessionManager::~SessionManager()
{
    m_stopping = true;
    if (m_shell      && m_shell->state()      != QProcess::NotRunning) m_shell->terminate();
    if (m_compositor && m_compositor->state() != QProcess::NotRunning) m_compositor->terminate();
}

// ─────────────────────────────────────────────────────────────────────────────
bool SessionManager::start()
{
    setupEnvironment();

    if (!m_skipPam && !pamAuthenticate()) {
        qCCritical(lcSession) << "PAM authentication failed";
        return false;
    }

    launchCompositor();
    return true;
}

// ─────────────────────────────────────────────────────────────────────────────
void SessionManager::setupEnvironment()
{
    // ── XDG base dirs ──────────────────────────────────────────────────────────
    if (qEnvironmentVariableIsEmpty("XDG_RUNTIME_DIR")) {
        const uid_t uid = getuid();
        QString rdir = QStringLiteral("/run/user/%1").arg(uid);
        QDir().mkpath(rdir);
        qputenv("XDG_RUNTIME_DIR", rdir.toLocal8Bit());
    }
    if (qEnvironmentVariableIsEmpty("XDG_CONFIG_HOME"))
        qputenv("XDG_CONFIG_HOME",
            QDir::homePath().append("/.config").toLocal8Bit());
    if (qEnvironmentVariableIsEmpty("XDG_DATA_HOME"))
        qputenv("XDG_DATA_HOME",
            QDir::homePath().append("/.local/share").toLocal8Bit());
    if (qEnvironmentVariableIsEmpty("XDG_CACHE_HOME"))
        qputenv("XDG_CACHE_HOME",
            QDir::homePath().append("/.cache").toLocal8Bit());

    // Standard XDG data dirs (include /usr/local for FreeBSD ports)
    if (qEnvironmentVariableIsEmpty("XDG_DATA_DIRS"))
        qputenv("XDG_DATA_DIRS",
            "/usr/local/share:/usr/share:" AETHER_DATADIR);

    // Wayland socket name
    if (qEnvironmentVariableIsEmpty("WAYLAND_DISPLAY"))
        qputenv("WAYLAND_DISPLAY", "wayland-0");

    // Qt / toolkit settings
    qputenv("QT_QPA_PLATFORM",              "wayland");
    qputenv("QT_WAYLAND_DISABLE_WINDOWDECORATION", "1");
    qputenv("GDK_BACKEND",                  "wayland");
    qputenv("MOZ_ENABLE_WAYLAND",           "1");
    qputenv("SDL_VIDEODRIVER",              "wayland");
    qputenv("CLUTTER_BACKEND",              "wayland");
    qputenv("_JAVA_AWT_WM_NONREPARENTING",  "1");

    // Locale
    if (qEnvironmentVariableIsEmpty("LANG")) qputenv("LANG", "en_US.UTF-8");

    qCDebug(lcSession) << "Environment configured";
}

// ─────────────────────────────────────────────────────────────────────────────
void SessionManager::launchCompositor()
{
    const QString binary = QStandardPaths::findExecutable("aether-compositor");
    if (binary.isEmpty()) {
        qCCritical(lcSession) << "aether-compositor not found in PATH";
        QCoreApplication::exit(1);
        return;
    }

    m_compositor = new QProcess(this);
    m_compositor->setProcessChannelMode(QProcess::ForwardedChannels);

    connect(m_compositor,
            QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, &SessionManager::onCompositorFinished);

    m_compositor->start(binary, {
        "--socket", qEnvironmentVariable("WAYLAND_DISPLAY", "wayland-0")
    });

    qCInfo(lcSession) << "Compositor started PID" << m_compositor->processId();
}

void SessionManager::launchShell()
{
    const QString binary = QStandardPaths::findExecutable("aether-shell");
    if (binary.isEmpty()) {
        qCWarning(lcSession) << "aether-shell not found in PATH";
        return;
    }

    m_shell = new QProcess(this);
    m_shell->setProcessChannelMode(QProcess::ForwardedChannels);
    m_shell->setEnvironment(QProcess::systemEnvironment());

    connect(m_shell,
            QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, &SessionManager::onShellFinished);

    m_shell->start(binary, {});
    qCInfo(lcSession) << "Shell started PID" << m_shell->processId();
}

// ─────────────────────────────────────────────────────────────────────────────
void SessionManager::onCompositorFinished(int code, QProcess::ExitStatus status)
{
    if (m_stopping) return;

    qCWarning(lcSession) << "Compositor exited with code" << code
                         << "status" << status;
    ++m_compositorCrashes;

    if (m_compositorCrashes >= MAX_CRASHES) {
        qCCritical(lcSession) << "Compositor crashed" << m_compositorCrashes
                              << "times; giving up";
        QCoreApplication::exit(1);
        return;
    }

    // Exponential backoff: 1s, 2s, 4s, 8s, 16s
    const int delay = 1000 * (1 << (m_compositorCrashes - 1));
    qCInfo(lcSession) << "Restarting compositor in" << delay << "ms";
    QTimer::singleShot(delay, this, &SessionManager::launchCompositor);
}

void SessionManager::onShellFinished(int code, QProcess::ExitStatus status)
{
    if (m_stopping) return;

    qCWarning(lcSession) << "Shell exited with code" << code;
    ++m_shellCrashes;

    if (m_shellCrashes >= MAX_CRASHES) {
        qCCritical(lcSession) << "Shell crashed" << m_shellCrashes << "times; giving up";
        return;
    }

    const int delay = 1000 * (1 << (m_shellCrashes - 1));
    QTimer::singleShot(delay, this, &SessionManager::launchShell);
}

// ─────────────────────────────────────────────────────────────────────────────
void SessionManager::requestLogout()
{
    qCInfo(lcSession) << "Logout requested";
    m_stopping = true;
    emit sessionEnding("logout");
    if (m_shell)      m_shell->terminate();
    if (m_compositor) m_compositor->terminate();
    QTimer::singleShot(3000, QCoreApplication::instance(), &QCoreApplication::quit);
}

void SessionManager::requestShutdown()
{
    logindCall("PowerOff", true);
}

void SessionManager::requestReboot()
{
    logindCall("Reboot", true);
}

void SessionManager::requestSuspend()
{
    logindCall("Suspend", false);
}

void SessionManager::requestHibernate()
{
    logindCall("Hibernate", false);
}

void SessionManager::requestLockScreen()
{
    emit lockScreenRequested();
    // Also signal logind so the screensaver activates on lock
    QDBusInterface logind("org.freedesktop.login1",
                          "/org/freedesktop/login1/session/auto",
                          "org.freedesktop.login1.Session",
                          QDBusConnection::systemBus());
    logind.asyncCall("Lock");
}

void SessionManager::requestRelaunchShell()
{
    if (m_shell) { m_shell->terminate(); }
    else         { launchShell(); }
}

// ─────────────────────────────────────────────────────────────────────────────
void SessionManager::logindCall(const QString &method, bool interactive)
{
    qCInfo(lcSession) << "logind" << method;
    QDBusInterface logind("org.freedesktop.login1",
                          "/org/freedesktop/login1",
                          "org.freedesktop.login1.Manager",
                          QDBusConnection::systemBus());
    if (logind.isValid()) {
        logind.asyncCall(method, interactive);
    } else {
        // Fallback: loginctl / shutdown / reboot
        const QString cmd = (method == "PowerOff")   ? "shutdown -p now"
                          : (method == "Reboot")      ? "reboot"
                          : (method == "Suspend")     ? "zzz"      // FreeBSD
                          : (method == "Hibernate")   ? "acpiconf -s 4"
                          : QString{};
        if (!cmd.isEmpty()) QProcess::startDetached("sh", {"-c", cmd});
    }
}

// ─────────────────────────────────────────────────────────────────────────────
bool SessionManager::pamAuthenticate()
{
#ifdef __linux__
    // Minimal PAM conversation that just returns success for auto-login
    // (real greeter handles PAM before launching the session manager).
    struct pam_conv conv = { [](int, const struct pam_message **,
                                struct pam_response **resp,
                                void *) -> int {
        *resp = static_cast<pam_response*>(calloc(1, sizeof(pam_response)));
        return PAM_SUCCESS;
    }, nullptr };

    pam_handle_t *pamh = nullptr;
    int ret = pam_start("aetherde", m_username.toLocal8Bit().constData(), &conv, &pamh);
    if (ret == PAM_SUCCESS) ret = pam_open_session(pamh, 0);
    pam_end(pamh, ret);
    return ret == PAM_SUCCESS;
#else
    // FreeBSD: PAM available but greeter handles auth before we run
    return true;
#endif
}

void SessionManager::restartProcess(QProcess *proc, const QString &name,
                                     const QStringList &args, int delayMs)
{
    QTimer::singleShot(delayMs, this, [proc, name, args]() {
        proc->start(name, args);
    });
}
