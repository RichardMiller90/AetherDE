# cmake/WaylandScanner.cmake
# Generates C glue code from Wayland protocol XML files using wayland-scanner.
#
# Usage:
#   wayland_generate_protocol(
#       TARGET      <target>
#       XML         <path/to/protocol.xml>
#       SERVER      # emit server header + glue   (optional)
#       CLIENT      # emit client header + glue   (optional, default)
#   )
#
# Appends generated sources to TARGET's PRIVATE sources and adds the
# generated header directory to its include path.

cmake_policy(SET CMP0057 NEW)

find_program(WAYLAND_SCANNER_EXECUTABLE wayland-scanner REQUIRED)

function(wayland_generate_protocol)
    cmake_parse_arguments(ARG "SERVER;CLIENT" "TARGET;XML" "" ${ARGN})

    if(NOT ARG_TARGET)
        message(FATAL_ERROR "wayland_generate_protocol: TARGET is required")
    endif()
    if(NOT ARG_XML)
        message(FATAL_ERROR "wayland_generate_protocol: XML is required")
    endif()

    get_filename_component(_basename "${ARG_XML}" NAME_WE)
    set(_outdir "${CMAKE_CURRENT_BINARY_DIR}/wayland-generated")
    file(MAKE_DIRECTORY "${_outdir}")

    set(_sources)

    # ── client ─────────────────────────────────────────────────────────────────
    if(ARG_CLIENT OR (NOT ARG_SERVER AND NOT ARG_CLIENT))
        set(_client_h   "${_outdir}/${_basename}-client.h")
        set(_client_c   "${_outdir}/${_basename}-client.c")

        add_custom_command(
            OUTPUT  "${_client_h}"
            COMMAND "${WAYLAND_SCANNER_EXECUTABLE}" client-header "${ARG_XML}" "${_client_h}"
            DEPENDS "${ARG_XML}"
            VERBATIM
        )
        add_custom_command(
            OUTPUT  "${_client_c}"
            COMMAND "${WAYLAND_SCANNER_EXECUTABLE}" private-code "${ARG_XML}" "${_client_c}"
            DEPENDS "${ARG_XML}"
            VERBATIM
        )
        list(APPEND _sources "${_client_h}" "${_client_c}")
    endif()

    # ── server ─────────────────────────────────────────────────────────────────
    if(ARG_SERVER)
        set(_server_h   "${_outdir}/${_basename}-server.h")
        set(_server_c   "${_outdir}/${_basename}-server.c")

        add_custom_command(
            OUTPUT  "${_server_h}"
            COMMAND "${WAYLAND_SCANNER_EXECUTABLE}" server-header "${ARG_XML}" "${_server_h}"
            DEPENDS "${ARG_XML}"
            VERBATIM
        )
        add_custom_command(
            OUTPUT  "${_server_c}"
            COMMAND "${WAYLAND_SCANNER_EXECUTABLE}" private-code "${ARG_XML}" "${_server_c}"
            DEPENDS "${ARG_XML}"
            VERBATIM
        )
        list(APPEND _sources "${_server_h}" "${_server_c}")
    endif()

    target_sources("${ARG_TARGET}" PRIVATE ${_sources})
    target_include_directories("${ARG_TARGET}" PRIVATE "${_outdir}")
endfunction()
